# Ground Up — Real-Life Simulation for Android

Ground Up 0.3.1 is an offline Android life simulation about making a living and building a real-world-style home from the ground up. The player is represented by a named avatar on a 420 m² plot. Money, time, materials, energy, housing costs, work, farming, livestock and market sales all interact through deterministic rules.

## Languages

The game includes English, Polish (**Polski**) and Turkish (**Türkçe**). It follows the phone's language when starting a new game if Android is configured for Polish or Turkish; English is the fallback. The language can also be changed in the avatar/game-settings dialog. The selection is stored with the local save and survives a restart.

## Playable features

- A custom-drawn isometric property scene that changes as construction progresses.
- Six construction phases: site preparation, foundations, brickwork, roof, windows/services, and interior finish.
- Material quantities using physical-style units (for example m³, kg, pieces, m²). Selected construction rates are benchmarked against dated Polish retail/price references; see `PRICE_CATALOG.md` for source links, units and limitations.
- Three jobs with different pay and energy costs; rest, daily expenses and wellbeing create trade-offs.
- A garden with a four-day growing cycle, harvest and market sale.
- A small chicken coop with up to four hens, feed consumption, egg production and sales.
- Avatar renaming, language selection, recent-life event log and a confirmed reset.
- Offline play and local save data encrypted with AES-256-GCM using a non-exportable Android Keystore key.
- No analytics, account, cloud dependency, network permission, NFT, crypto-wallet or real-money trading features.

This is a first playable simulation chapter, not a finished open-world 3D game. The property view is custom-drawn 2D/isometric artwork and the starter avatar portrait is realistic, but appearance customization is not implemented yet. Selected material rates use dated Polish price benchmarks; other prices and construction quantities remain game estimates, not live supplier quotations. See `PRICE_CATALOG.md` and `REALISM_AND_SCOPE.md`. Real construction or physical purchasing is not triggered by game actions.

## Build requirements

- Android SDK Platform 35 and Build Tools 35.0.0.
- JDK 17.
- Gradle 8.10.2 (the supplied `gradlew` downloads the official distribution on first use and checks its SHA-256 checksum).
- Internet access for the initial Gradle/Maven dependency download, unless those artifacts are already cached.
- Android 11 / API 30 or newer.

The project uses Kotlin 2.0.21, Jetpack Compose, Material 3 and Android Gradle Plugin 8.7.3.

## Build and install

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Alternatively, copy `app/build/outputs/apk/debug/app-debug.apk` to your phone and open it. Allow installation from that file source if Android requests it. The debug APK is signed for immediate testing; it is not a Play Store release artifact.

## GitHub Actions

For the ZIP-upload workflow used in this delivery, create `.github/workflows/build-ground-up.yml` in the GitHub repository using the separately supplied `build-ground-up.yml` file, and upload `ground-up.zip` to the repository root. The source ZIP contains the Gradle project at its root; the workflow extracts it into a fresh `extracted-ground-up/` folder. That workflow extracts the ZIP, runs JVM unit tests and Android lint, builds the debug APK, and uploads the APK plus SHA-256 checksum as the `ground-up-debug-apk` artifact. No signing secrets are needed for a debug APK.

## Architecture and data protection

- `GameState` is the serializable game state; `GameEngine` contains deterministic and testable economic rules.
- `GameViewModel` runs save/load on an IO dispatcher and exposes UI state through `StateFlow`.
- `EncryptedGameStore` encrypts the local JSON save with AES-256-GCM. The key is generated in Android Keystore and is not exportable from the app.
- Save files live in the app-private `noBackupFilesDir`; Android cloud/device-transfer backups are disabled.
- The game is fully playable offline. The price catalog records dated reference values and limitations; prices are not connected to a live market.

## Testing and verification boundary

Unit tests cover the main economy loop (work, shift energy requirements, daily cost, building prerequisites, material inventory, crop cycle and completed-home rent reduction) and the English/Polish/Turkish text selection and dynamic labels. Android SDK/Gradle binaries were not installed in the authoring container, so this environment could not produce or execute a real APK. The supplied GitHub Actions workflow is configured to perform the authoritative Android compile, test, lint and APK build on a runner with the required SDK.
