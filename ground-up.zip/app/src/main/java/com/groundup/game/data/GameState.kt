package com.groundup.game.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

fun defaultGameLanguageCode(): String = when (Locale.getDefault().language.lowercase(Locale.ROOT)) {
    "pl" -> "pl"
    "tr" -> "tr"
    else -> "en"
}

/** Saved state for the offline Ground Up life simulation. Money is expressed in PLN. */
data class GameState(
    val playerName: String = "You",
    val languageCode: String = defaultGameLanguageCode(),
    val day: Int = 1,
    val money: Int = 18_000,
    val energy: Int = 100,
    val wellbeing: Int = 100,
    /** Number of construction phases completed: 0..6. */
    val homeStage: Int = 0,
    val inventory: Map<String, Int> = emptyMap(),
    val seedPacks: Int = 0,
    val cropPlantedDay: Int? = null,
    val vegetables: Int = 0,
    val coopBuilt: Boolean = false,
    val chickens: Int = 0,
    val feedBags: Int = 0,
    val eggs: Int = 0,
    val lastEggDay: Int = 1,
    val log: List<String> = listOf("You inherited a 420 m² plot and have 18,000 zł saved. Build a home without running out of money."),
) {
    fun safe(): GameState = copy(
        playerName = playerName.trim().take(28).ifBlank { "You" },
        languageCode = languageCode.lowercase(Locale.ROOT).takeIf { it in setOf("en", "pl", "tr") } ?: defaultGameLanguageCode(),
        day = day.coerceAtLeast(1),
        money = money.coerceAtLeast(0),
        energy = energy.coerceIn(0, 100),
        wellbeing = wellbeing.coerceIn(0, 100),
        homeStage = homeStage.coerceIn(0, 6),
        inventory = inventory.filterKeys { it.length <= 48 }.mapValues { it.value.coerceIn(0, 1_000_000) },
        seedPacks = seedPacks.coerceIn(0, 1_000),
        vegetables = vegetables.coerceIn(0, 100_000),
        chickens = chickens.coerceIn(0, 4),
        feedBags = feedBags.coerceIn(0, 10_000),
        eggs = eggs.coerceIn(0, 100_000),
        lastEggDay = lastEggDay.coerceAtLeast(1),
        log = log.take(20).map { it.take(240) },
    )

    val ownsHome: Boolean get() = homeStage >= 6
    val nextStage: BuildStage? get() = BUILD_STAGES.getOrNull(homeStage)
    val cropReady: Boolean get() = cropPlantedDay != null && day - cropPlantedDay >= 4
    val dailyLivingCost: Int get() = if (ownsHome) 85 else 145
}

data class MaterialRequirement(
    val id: String,
    val name: String,
    val quantity: Int,
    val unit: String,
    val unitPrice: Int,
) {
    val total: Int get() = quantity * unitPrice
}

data class BuildStage(
    val index: Int,
    val name: String,
    val subtitle: String,
    val requirements: List<MaterialRequirement>,
    val buildDays: Int = 1,
) {
    val totalCost: Int get() = requirements.sumOf { it.total }
}

val BUILD_STAGES = listOf(
    BuildStage(0, "Site preparation", "Clear and level the ground", listOf(
        MaterialRequirement("excavator_day", "Mini excavator hire · 1 day", 1, "day", 1_200),
        MaterialRequirement("gravel_t", "Compacted gravel", 8, "tonnes", 240),
    )),
    BuildStage(1, "Foundation", "A stable base for the house", listOf(
        MaterialRequirement("concrete_m3", "Ready-mix concrete C20/25", 6, "m³", 517),
        MaterialRequirement("rebar_kg", "Steel reinforcement B500", 180, "kg", 5),
        MaterialRequirement("formwork_set", "Formwork kit", 1, "set", 780),
    ), buildDays = 2),
    BuildStage(2, "Brickwork", "Load-bearing walls and lintels", listOf(
        MaterialRequirement("brick_piece", "Ceramic masonry units", 1_800, "pieces", 7),
        MaterialRequirement("mortar_bag", "Masonry mortar", 45, "25 kg bags", 17),
        MaterialRequirement("lintel_piece", "Reinforced lintels", 6, "pieces", 165),
    ), buildDays = 3),
    BuildStage(3, "Roof", "Timber structure, membrane and tiles", listOf(
        MaterialRequirement("timber_m3", "Structural timber", 2, "m³", 2_310),
        MaterialRequirement("roof_tile_m2", "Ceramic roof tiles", 75, "m²", 59),
        MaterialRequirement("roof_membrane_roll", "Roof membrane", 2, "rolls", 290),
    ), buildDays = 3),
    BuildStage(4, "Windows & services", "Close the shell and connect utilities", listOf(
        MaterialRequirement("cable_m", "Electrical cable", 120, "metres", 6),
        MaterialRequirement("pipe_m", "Water and waste pipe", 60, "metres", 18),
        MaterialRequirement("window_unit", "Double-glazed window", 6, "units", 1_750),
        MaterialRequirement("entry_door", "Insulated entrance door", 1, "unit", 1_350),
    ), buildDays = 2),
    BuildStage(5, "Interior finish", "Plaster, floors and paint", listOf(
        MaterialRequirement("plaster_m2", "Interior plaster", 100, "m²", 17),
        MaterialRequirement("floor_m2", "Floor finish", 65, "m²", 48),
        MaterialRequirement("paint_l", "Interior paint", 20, "litres", 95),
    ), buildDays = 3),
)

data class Job(val id: String, val title: String, val details: String, val pay: Int, val energyCost: Int)
val JOBS = listOf(
    Job("site", "Construction helper", "Carry materials and help a local crew", 680, 34),
    Job("warehouse", "Warehouse shift", "Pick and pack orders · steady hours", 590, 26),
    Job("delivery", "Delivery route", "Deliver parcels around the district", 740, 38),
)

object GameEngine {
    fun work(state: GameState, jobId: String): GameState {
        val job = JOBS.firstOrNull { it.id == jobId } ?: error("That job is not available.")
        require(state.energy >= job.energyCost) { "This shift requires ${job.energyCost} energy. Rest first to recover enough energy." }
        val paid = state.copy(money = state.money + job.pay, energy = state.energy - job.energyCost)
        return advanceDay(paid, "You completed a ${job.title.lowercase()} and earned ${job.pay} zł.")
    }

    fun rest(state: GameState): GameState = advanceDay(
        state.copy(energy = (state.energy + 58).coerceAtMost(100), wellbeing = (state.wellbeing + 3).coerceAtMost(100)),
        "You took a proper rest. Energy recovered.",
    )

    fun buyMaterials(state: GameState): GameState {
        val stage = state.nextStage ?: error("Your starter home is complete. There's nothing left to build in this chapter.")
        val missing = stage.requirements.filter { (state.inventory[it.id] ?: 0) < it.quantity }
        require(missing.isNotEmpty()) { "You already have all materials for this stage. Start building." }
        val cost = missing.sumOf { it.total }
        require(state.money >= cost + state.dailyLivingCost) {
            "The order costs ${cost} zł. Keep at least ${state.dailyLivingCost} zł for daily living costs."
        }
        val inventory = state.inventory.toMutableMap()
        missing.forEach { req -> inventory[req.id] = (inventory[req.id] ?: 0) + req.quantity }
        return advanceDay(state.copy(money = state.money - cost, inventory = inventory), "Materials delivered for ${stage.name.lowercase()} · ${cost} zł.")
    }

    fun buildNextStage(state: GameState): GameState {
        val stage = state.nextStage ?: error("Your starter home is complete.")
        require(state.energy >= 20) { "You're too tired to build safely. Rest first." }
        val missing = stage.requirements.filter { (state.inventory[it.id] ?: 0) < it.quantity }
        require(missing.isEmpty()) { "Materials are missing. Order the ${stage.name.lowercase()} package first." }
        val inventory = state.inventory.toMutableMap()
        stage.requirements.forEach { req -> inventory[req.id] = (inventory[req.id] ?: 0) - req.quantity }
        val completed = state.copy(homeStage = state.homeStage + 1, inventory = inventory, energy = state.energy - 20)
        val line = if (completed.ownsHome) "Your home is complete. You no longer pay rent." else "${stage.name} complete · ${stage.buildDays} days of work represented."
        return advanceDay(completed, line, extraDays = stage.buildDays - 1)
    }

    fun buySeeds(state: GameState): GameState {
        val cost = 80
        require(state.money >= cost + state.dailyLivingCost) { "You need ${cost} zł, plus money for daily living costs." }
        return advanceDay(state.copy(money = state.money - cost, seedPacks = state.seedPacks + 1), "You bought a packet of vegetable seeds for 80 zł.")
    }

    fun plantSeeds(state: GameState): GameState {
        require(state.seedPacks > 0) { "Buy seeds from the market first." }
        require(state.cropPlantedDay == null) { "The garden bed is already growing. Harvest before planting again." }
        return advanceDay(state.copy(seedPacks = state.seedPacks - 1, cropPlantedDay = state.day + 1), "You planted the garden. The vegetables need four days to grow.")
    }

    fun harvest(state: GameState): GameState {
        require(state.cropReady) { "The vegetables aren't ready yet. They need four full days to grow." }
        return advanceDay(state.copy(cropPlantedDay = null, vegetables = state.vegetables + 20), "You harvested 20 portions of vegetables.")
    }

    fun sellVegetables(state: GameState): GameState {
        require(state.vegetables > 0) { "There are no vegetables to sell. Harvest the garden first." }
        val earnings = state.vegetables * 12
        return advanceDay(state.copy(money = state.money + earnings, vegetables = 0), "Sold your vegetables at the local market for ${earnings} zł.")
    }

    fun buildCoop(state: GameState): GameState {
        require(!state.coopBuilt) { "You already have a chicken coop." }
        require(state.money >= 1_000 + state.dailyLivingCost) { "The coop costs 1,000 zł. Keep money for daily living costs." }
        return advanceDay(state.copy(money = state.money - 1_000, coopBuilt = true), "You built a small, fenced chicken coop for 1,000 zł.")
    }

    fun buyChicken(state: GameState): GameState {
        require(state.coopBuilt) { "Build the coop before buying animals." }
        require(state.chickens < 4) { "This small coop can safely house up to four chickens." }
        require(state.money >= 220 + state.dailyLivingCost) { "A healthy hen costs 220 zł. Keep money for daily living costs." }
        return advanceDay(state.copy(money = state.money - 220, chickens = state.chickens + 1), "You brought home a healthy hen for 220 zł.")
    }

    fun buyFeed(state: GameState): GameState {
        require(state.chickens > 0) { "Buy a hen first." }
        require(state.money >= 65 + state.dailyLivingCost) { "Feed costs 65 zł. Keep money for daily living costs." }
        return advanceDay(state.copy(money = state.money - 65, feedBags = state.feedBags + 1), "You bought a bag of poultry feed for 65 zł.")
    }

    fun sellEggs(state: GameState): GameState {
        require(state.eggs > 0) { "You don't have eggs to sell yet. Keep the chickens fed." }
        val earnings = state.eggs * 3
        return advanceDay(state.copy(money = state.money + earnings, eggs = 0), "Sold ${state.eggs} eggs at 3 zł each · ${earnings} zł.")
    }

    fun rename(state: GameState, name: String): GameState {
        val clean = name.trim().take(28)
        require(clean.isNotBlank()) { "Enter a name for your avatar." }
        return state.copy(playerName = clean)
    }

    fun reset(): GameState = GameState()

    private fun advanceDay(input: GameState, event: String, extraDays: Int = 0): GameState {
        var s = input.copy(log = (listOf(event) + input.log).take(20))
        val count = (extraDays + 1).coerceAtMost(10)
        repeat(count) {
            val nextDay = s.day + 1
            var feed = s.feedBags
            var eggs = s.eggs
            var lastEggDay = s.lastEggDay
            var newLog = s.log
            if (s.chickens > 0 && feed > 0 && nextDay - lastEggDay >= 3) {
                eggs += s.chickens * 2
                feed -= 1
                lastEggDay = nextDay
                newLog = (listOf("Your hens laid ${s.chickens * 2} eggs.") + newLog).take(20)
            }
            val cost = if (s.ownsHome) 85 else 145
            val shortfall = s.money < cost
            s = s.copy(
                day = nextDay,
                money = (s.money - cost).coerceAtLeast(0),
                energy = if (shortfall) (s.energy - 12).coerceAtLeast(0) else s.energy,
                wellbeing = if (shortfall) (s.wellbeing - 7).coerceAtLeast(0) else s.wellbeing,
                feedBags = feed,
                eggs = eggs,
                lastEggDay = lastEggDay,
                log = if (shortfall) (listOf("Daily living costs were ${cost} zł. You couldn't cover everything.") + newLog).take(20) else newLog,
            )
            if (s.money == 0 && s.wellbeing < 20) {
                s = s.copy(log = (listOf("Money is running low. Take a paid shift before making more purchases.") + s.log).take(20))
            }
        }
        return s.safe()
    }
}

object GameStateCodec {
    fun encode(state: GameState): ByteArray {
        val inventory = JSONObject()
        state.inventory.forEach { (id, qty) -> inventory.put(id, qty) }
        val log = JSONArray()
        state.log.take(20).forEach(log::put)
        val json = JSONObject().apply {
            put("schemaVersion", 1)
            put("playerName", state.playerName)
            put("languageCode", state.languageCode)
            put("day", state.day)
            put("money", state.money)
            put("energy", state.energy)
            put("wellbeing", state.wellbeing)
            put("homeStage", state.homeStage)
            put("inventory", inventory)
            put("seedPacks", state.seedPacks)
            if (state.cropPlantedDay == null) put("cropPlantedDay", JSONObject.NULL) else put("cropPlantedDay", state.cropPlantedDay)
            put("vegetables", state.vegetables)
            put("coopBuilt", state.coopBuilt)
            put("chickens", state.chickens)
            put("feedBags", state.feedBags)
            put("eggs", state.eggs)
            put("lastEggDay", state.lastEggDay)
            put("log", log)
        }
        return json.toString().toByteArray(Charsets.UTF_8)
    }

    fun decode(bytes: ByteArray): GameState {
        require(bytes.size <= 1_000_000) { "The save file is too large." }
        val root = JSONObject(bytes.toString(Charsets.UTF_8))
        require(root.optInt("schemaVersion", -1) == 1) { "This save version is not supported." }
        val inventoryJson = root.optJSONObject("inventory") ?: JSONObject()
        val inventory = mutableMapOf<String, Int>()
        val keys = inventoryJson.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            inventory[key.take(48)] = inventoryJson.optInt(key, 0).coerceIn(0, 1_000_000)
        }
        val logs = root.optJSONArray("log")
        val log = buildList {
            if (logs != null) for (i in 0 until minOf(logs.length(), 20)) add(logs.optString(i).take(240))
        }
        val crop = if (root.isNull("cropPlantedDay")) null else root.optInt("cropPlantedDay", 0).coerceAtLeast(1)
        return GameState(
            playerName = root.optString("playerName", "You"),
            languageCode = root.optString("languageCode", defaultGameLanguageCode()),
            day = root.optInt("day", 1), money = root.optInt("money", 18_000),
            energy = root.optInt("energy", 100), wellbeing = root.optInt("wellbeing", 100),
            homeStage = root.optInt("homeStage", 0), inventory = inventory,
            seedPacks = root.optInt("seedPacks", 0), cropPlantedDay = crop,
            vegetables = root.optInt("vegetables", 0), coopBuilt = root.optBoolean("coopBuilt", false),
            chickens = root.optInt("chickens", 0), feedBags = root.optInt("feedBags", 0),
            eggs = root.optInt("eggs", 0), lastEggDay = root.optInt("lastEggDay", 1),
            log = log.ifEmpty { listOf("Welcome back. Your life is waiting.") },
        ).safe()
    }
}
