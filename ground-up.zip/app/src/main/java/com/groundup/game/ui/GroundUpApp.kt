package com.groundup.game.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.groundup.game.data.GameState
import com.groundup.game.data.GameViewModel
import com.groundup.game.data.JOBS
import com.groundup.game.data.MaterialRequirement

private enum class Destination(val label: String) {
    WORLD("World"), WORK("Work"), MARKET("Market"), FARM("Farm")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroundUpApp() {
    val viewModel: GameViewModel = viewModel()
    val ui by viewModel.state.collectAsStateWithLifecycle()
    var destination by rememberSaveable { mutableStateOf(Destination.WORLD) }
    var profileOpen by rememberSaveable { mutableStateOf(false) }
    var resetConfirm by rememberSaveable { mutableStateOf(false) }
    var nameDraft by rememberSaveable { mutableStateOf("") }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { viewModel.loadIfNeeded() }
    LaunchedEffect(ui.hasLoaded, ui.game.languageCode) {
        if (ui.hasLoaded) GameLanguageManager.set(ui.game.languageCode)
    }
    LaunchedEffect(ui.notice) {
        val message = ui.notice
        if (message != null) {
            snackbar.showSnackbar(translateGameText(message, ui.game.languageCode))
            viewModel.clearNotice()
        }
    }
    BackHandler(enabled = profileOpen || resetConfirm) {
        if (resetConfirm) resetConfirm = false else profileOpen = false
    }

    if (ui.loading || !ui.hasLoaded && ui.storageError == null) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                CircularProgressIndicator()
                GameText("Loading your life…", style = MaterialTheme.typography.bodyMedium)
            }
        }
        return
    }
    if (ui.storageError != null && !ui.hasLoaded) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp), contentAlignment = Alignment.Center) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Lock, null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.error)
                GameText("Your save couldn't be opened", style = MaterialTheme.typography.headlineSmall)
                GameText(ui.storageError.orEmpty(), style = MaterialTheme.typography.bodyMedium)
                Button(onClick = viewModel::retryLoad) { GameText("Try again") }
                OutlinedButton(onClick = { viewModel.resetGame() }) { GameText("Start a new life") }
                GameText("Starting a new life replaces the unreadable save.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    val game = ui.game
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            Column(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars).background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp, vertical = 11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Home, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(25.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        GameText("GROUND UP", style = MaterialTheme.typography.titleLarge, letterSpacing = 1.4.sp, fontWeight = FontWeight.ExtraBold)
                        GameText("A LIFE, BUILT BY YOU", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.0.sp)
                    }
                    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = CircleShape) {
                        Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(com.groundup.game.R.drawable.player_avatar),
                                contentDescription = "Realistic player avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(25.dp).clip(CircleShape),
                            )
                            Spacer(Modifier.width(6.dp))
                            GameText(game.playerName, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSecondaryContainer, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    IconButton(onClick = { nameDraft = game.playerName; profileOpen = true }, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Filled.Settings, contentDescription = translateGameText("Avatar and game settings", GameLanguageManager.code))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    StatChip("DAY ${game.day}", Modifier.weight(0.75f))
                    StatChip("${game.money} zł", Modifier.weight(1f), money = true)
                    StatChip("ENERGY ${game.energy}%", Modifier.weight(1.15f))
                }
            }
        },
        bottomBar = {
            NavigationBar(windowInsets = WindowInsets.navigationBars) {
                Destination.entries.forEach { item ->
                    val icon = when (item) {
                        Destination.WORLD -> Icons.Filled.Home
                        Destination.WORK -> Icons.Filled.Work
                        Destination.MARKET -> Icons.Filled.Storefront
                        Destination.FARM -> Icons.Filled.Agriculture
                    }
                    NavigationBarItem(
                        selected = destination == item,
                        onClick = { destination = item },
                        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(23.dp)) },
                        label = { GameText(item.label) },
                    )
                }
            }
        },
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (ui.storageError != null && ui.hasLoaded) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        GameText("Save warning", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        GameText("${ui.storageError}. Keep Ground Up open until saving succeeds; consider taking a screenshot of your current progress.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
            when (destination) {
                Destination.WORLD -> WorldScreen(game, ui.saving, viewModel::buyMaterials, viewModel::buildNextStage, { destination = Destination.MARKET }, { destination = Destination.WORK })
                Destination.WORK -> WorkScreen(game, viewModel::work, viewModel::rest)
                Destination.MARKET -> MarketScreen(game, viewModel::buyMaterials, viewModel::buySeeds, viewModel::buyFeed, { destination = Destination.FARM })
                Destination.FARM -> FarmScreen(game, viewModel::buySeeds, viewModel::plantSeeds, viewModel::harvest, viewModel::sellVegetables, viewModel::buildCoop, viewModel::buyChicken, viewModel::buyFeed, viewModel::sellEggs)
            }
            Spacer(Modifier.height(8.dp))
            GameText("SELECT POLISH PRICE BENCHMARKS · CHECKED 25 OCT 2026 · SEE PRICE CATALOG FOR SOURCES AND ESTIMATES", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (profileOpen) {
        AlertDialog(
            onDismissRequest = { profileOpen = false },
            title = { GameText("Your life") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(com.groundup.game.R.drawable.player_avatar),
                            contentDescription = "Realistic Ground Up player avatar",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.width(100.dp).height(150.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                            GameText("Your character", style = MaterialTheme.typography.titleMedium)
                            GameText("A grounded, human-proportioned starter avatar. This is a realistic portrait, not a cartoon character.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            GameText("More appearance customization is planned; it is not yet available in this build.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    GameText("Your avatar represents you in this world. Your progress is saved on this device.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(value = nameDraft, onValueChange = { nameDraft = it.take(28) }, label = { GameText("Avatar name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    GameText("Language", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        GAME_LANGUAGES.forEach { option ->
                            if (game.languageCode == option.code) {
                                Button(onClick = { viewModel.setLanguage(option.code); GameLanguageManager.set(option.code) }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
                                    GameText(option.nativeName, maxLines = 1)
                                }
                            } else {
                                OutlinedButton(onClick = { viewModel.setLanguage(option.code); GameLanguageManager.set(option.code) }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
                                    GameText(option.nativeName, maxLines = 1)
                                }
                            }
                        }
                    }
                    GameText("Your save is encrypted on-device. No account or network connection is used.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    HorizontalDivider()
                    TextButton(onClick = { profileOpen = false; resetConfirm = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.RestartAlt, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); GameText("Start over", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = { Button(onClick = { viewModel.rename(nameDraft); profileOpen = false }) { GameText("Save avatar") } },
            dismissButton = { TextButton(onClick = { profileOpen = false }) { GameText("Cancel") } },
        )
    }
    if (resetConfirm) {
        AlertDialog(
            onDismissRequest = { resetConfirm = false },
            title = { GameText("Start a new life?") },
            text = { GameText("This permanently replaces your current local save with a new plot, new budget and Day 1. There is no undo.") },
            confirmButton = { Button(onClick = { viewModel.resetGame(); destination = Destination.WORLD; resetConfirm = false }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { GameText("Reset life") } },
            dismissButton = { TextButton(onClick = { resetConfirm = false }) { GameText("Keep playing") } },
        )
    }
}

@Composable
private fun StatChip(text: String, modifier: Modifier = Modifier, money: Boolean = false) {
    Surface(modifier, color = if (money) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(10.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        GameText(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium, color = if (money) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun SectionTitle(kicker: String, title: String, description: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        GameText(kicker.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary, letterSpacing = 1.1.sp)
        GameText(title, style = MaterialTheme.typography.headlineMedium)
        if (description != null) GameText(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InfoCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun WorldScreen(game: GameState, saving: Boolean, onBuyMaterials: () -> Unit, onBuild: () -> Unit, goMarket: () -> Unit, goWork: () -> Unit) {
    SectionTitle("YOUR PROPERTY · 420 m²", "Build a life from the ground up", "A plot, a budget, and real-world choices. Every day costs money.")
    Box {
        EstateScene(game.homeStage, game.playerName, game.inventory.isNotEmpty(), Modifier.fillMaxWidth().aspectRatio(1.22f).clip(RoundedCornerShape(22.dp)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(22.dp)))
        Surface(color = Color(0xD91D271F), shape = RoundedCornerShape(bottomEnd = 14.dp), modifier = Modifier.align(Alignment.TopStart)) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                GameText("YOUR PLOT", style = MaterialTheme.typography.labelSmall, color = Color(0xFFD9E9CE), letterSpacing = 1.1.sp)
                GameText(if (game.ownsHome) "Your own home" else "Small starter house", style = MaterialTheme.typography.titleMedium, color = Color.White)
            }
        }
        Surface(color = Color(0xD9FFFFFF), shape = CircleShape, modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp)) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                if (saving) CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF36573D), modifier = Modifier.size(13.dp))
                Spacer(Modifier.width(6.dp))
                GameText(if (saving) "Saving" else "Saved", style = MaterialTheme.typography.labelSmall, color = Color(0xFF27332A))
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MetricCard("WELLBEING", "${game.wellbeing}%", game.wellbeing / 100f, Modifier.weight(1f))
        MetricCard("HOME", "${game.homeStage}/6", game.homeStage / 6f, Modifier.weight(1f))
        MetricCard("DAILY COST", "${game.dailyLivingCost} zł", null, Modifier.weight(1f))
    }
    val stage = game.nextStage
    if (stage == null) {
        InfoCard {
            GameText("A home of your own.", style = MaterialTheme.typography.titleLarge)
            GameText("You've completed the starter house. Rent is gone; your daily living costs are lower. Keep working on your land, garden and flock.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { goMarket() }, modifier = Modifier.fillMaxWidth()) { GameText("Visit local market"); Spacer(Modifier.width(8.dp)); Icon(Icons.Filled.ArrowForward, null) }
        }
    } else {
        val missing = stage.requirements.filter { (game.inventory[it.id] ?: 0) < it.quantity }
        val packageCost = missing.sumOf { it.total }
        val hasAll = missing.isEmpty()
        InfoCard {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    GameText("NEXT CONSTRUCTION PHASE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary, letterSpacing = 0.8.sp)
                    GameText(stage.name, style = MaterialTheme.typography.titleLarge)
                    GameText(stage.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(12.dp)) {
                    GameText("${stage.buildDays} ${if (stage.buildDays == 1) "day" else "days"}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
            stage.requirements.forEach { req -> MaterialLine(req, game.inventory[req.id] ?: 0) }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GameText(if (hasAll) "Materials ready" else "Materials still needed", style = MaterialTheme.typography.titleSmall)
                GameText("${packageCost} zł", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            }
            if (hasAll) {
                Button(onClick = onBuild, modifier = Modifier.fillMaxWidth(), enabled = game.energy >= 20) {
                    Icon(Icons.Filled.Construction, null); Spacer(Modifier.width(8.dp)); GameText("Build ${stage.name.lowercase()}")
                }
                if (game.energy < 20) GameText("Rest to at least 20% energy before building.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            } else {
                Button(onClick = onBuyMaterials, modifier = Modifier.fillMaxWidth(), enabled = game.money >= packageCost + game.dailyLivingCost) {
                    Icon(Icons.Filled.ShoppingCart, null); Spacer(Modifier.width(8.dp)); GameText("Order missing materials · ${packageCost} zł")
                }
                if (game.money < packageCost + game.dailyLivingCost) {
                    GameText("You need ${packageCost} zł and must keep ${game.dailyLivingCost} zł for today's living costs.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    OutlinedButton(onClick = goWork, modifier = Modifier.fillMaxWidth()) { GameText("Earn money first") }
                }
            }
        }
    }
    InfoCard {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.ArrowForward, null, tint = MaterialTheme.colorScheme.secondary); Spacer(Modifier.width(8.dp)); GameText("RECENT LIFE EVENTS", style = MaterialTheme.typography.labelLarge, letterSpacing = 0.8.sp) }
        game.log.take(5).forEachIndexed { index, event ->
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.padding(top = 6.dp).size(7.dp).clip(CircleShape).background(if (index == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant))
                GameText(event, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, progress: Float?, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            GameText(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            GameText(value, style = MaterialTheme.typography.titleMedium, maxLines = 1)
            if (progress != null) LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(4.dp), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.outlineVariant)
        }
    }
}

@Composable
private fun MaterialLine(req: MaterialRequirement, inStock: Int) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            GameText(req.name, style = MaterialTheme.typography.bodyMedium)
            GameText("${req.quantity} ${req.unit} × ${req.unitPrice} zł", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            GameText("${req.total} zł", style = MaterialTheme.typography.labelLarge)
            GameText(if (inStock >= req.quantity) "READY" else if (inStock > 0) "$inStock / ${req.quantity}" else "NOT ORDERED", style = MaterialTheme.typography.labelSmall, color = if (inStock >= req.quantity) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun WorkScreen(game: GameState, onWork: (String) -> Unit, onRest: () -> Unit) {
    SectionTitle("EARN A LIVING", "Your time has value", "Work pays the bills. Hard shifts cost energy; resting costs a day of living expenses.")
    InfoCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                GameText("Energy", style = MaterialTheme.typography.titleMedium)
                GameText("${game.energy}% available", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            GameText(if (game.energy >= 60) "Ready for work" else if (game.energy >= 25) "Take it steady" else "Need rest", style = MaterialTheme.typography.labelLarge, color = if (game.energy >= 25) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        }
        LinearProgressIndicator(progress = { game.energy / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.surfaceVariant)
        GameText("Living costs: ${game.dailyLivingCost} zł per day", style = MaterialTheme.typography.bodyMedium)
        GameText("Current savings: ${game.money} zł", style = MaterialTheme.typography.titleLarge)
    }
    JOBS.forEach { job ->
        InfoCard {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Work, null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    GameText(job.title, style = MaterialTheme.typography.titleMedium)
                    GameText(job.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        GameText("+${job.pay} zł", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                        GameText("−${job.energyCost}% energy", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Button(onClick = { onWork(job.id) }, modifier = Modifier.fillMaxWidth(), enabled = game.energy >= 25) { GameText("Work one shift") }
            if (game.energy < 25) GameText("You're too tired for a safe shift. Rest first.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
    InfoCard {
        GameText("Take a day off", style = MaterialTheme.typography.titleMedium)
        GameText("Rest restores up to 58 energy and improves wellbeing a little. You still pay for food, rent and utilities.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = onRest, modifier = Modifier.fillMaxWidth()) { GameText("Rest and recover") }
    }
}

@Composable
private fun MarketScreen(game: GameState, onBuyMaterials: () -> Unit, onBuySeeds: () -> Unit, onBuyFeed: () -> Unit, goFarm: () -> Unit) {
    SectionTitle("LOCAL SUPPLIERS", "Buy what you need", "Materials are priced by real-world units. Ordering advances one day and daily living costs still apply.")
    val stage = game.nextStage
    if (stage == null) {
        InfoCard {
            GameText("Starter house completed", style = MaterialTheme.typography.titleLarge)
            GameText("Your construction account is clear for this chapter. Buy seeds and animal feed for the garden and coop.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        InfoCard {
            GameText("${stage.name} · material order", style = MaterialTheme.typography.titleLarge)
            GameText("A complete order for the next stage", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            stage.requirements.forEach { MaterialLine(it, game.inventory[it.id] ?: 0) }
            HorizontalDivider()
            val missing = stage.requirements.filter { (game.inventory[it.id] ?: 0) < it.quantity }
            val cost = missing.sumOf { it.total }
            GameText("${cost} zł", style = MaterialTheme.typography.headlineMedium)
            Button(onClick = onBuyMaterials, modifier = Modifier.fillMaxWidth(), enabled = missing.isNotEmpty() && game.money >= cost + game.dailyLivingCost) {
                Icon(Icons.Filled.ShoppingCart, null); Spacer(Modifier.width(8.dp)); GameText(if (missing.isEmpty()) "Order already complete" else "Order missing items")
            }
            if (missing.isEmpty()) GameText("All materials are in your inventory. Build the stage from the World tab.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            else if (game.money < cost + game.dailyLivingCost) GameText("Not enough money while keeping daily costs covered. Take a shift first.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
    InfoCard {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.LocalFlorist, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(9.dp)); GameText("Garden supplies", style = MaterialTheme.typography.titleLarge) }
        GameText("Vegetable seed packet · 80 zł", style = MaterialTheme.typography.bodyMedium)
        GameText("One packet plants one bed. After four days, harvest 20 portions that can be sold at the market.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = onBuySeeds, modifier = Modifier.fillMaxWidth(), enabled = game.money >= 80 + game.dailyLivingCost) { GameText("Buy seed packet") }
    }
    if (game.chickens > 0) {
        InfoCard {
            GameText("Poultry supplies", style = MaterialTheme.typography.titleLarge)
            GameText("Feed bag · 65 zł · a fed flock can lay eggs every three days.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onBuyFeed, modifier = Modifier.fillMaxWidth(), enabled = game.money >= 65 + game.dailyLivingCost) { GameText("Buy feed") }
        }
    }
    FilledTonalButton(onClick = goFarm, modifier = Modifier.fillMaxWidth()) { GameText("Manage your farm"); Spacer(Modifier.width(8.dp)); Icon(Icons.Filled.ArrowForward, null) }
}

@Composable
private fun FarmScreen(
    game: GameState,
    onBuySeeds: () -> Unit,
    onPlant: () -> Unit,
    onHarvest: () -> Unit,
    onSellVegetables: () -> Unit,
    onBuildCoop: () -> Unit,
    onBuyChicken: () -> Unit,
    onBuyFeed: () -> Unit,
    onSellEggs: () -> Unit,
) {
    SectionTitle("LAND & LIVESTOCK", "A small working farm", "Grow something, care for animals, and learn what it takes to keep a property running.")
    InfoCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE1E9D9)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.LocalFlorist, null, tint = Color(0xFF36573D), modifier = Modifier.size(29.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                GameText("Vegetable garden", style = MaterialTheme.typography.titleLarge)
                GameText(when {
                    game.cropReady -> "Ready to harvest · 20 portions"
                    game.cropPlantedDay != null -> "Growing · ${((4 - (game.day - game.cropPlantedDay)).coerceAtLeast(0))} days remaining"
                    game.vegetables > 0 -> "Harvest stored · ${game.vegetables} portions"
                    else -> "One bed · seed, grow, harvest, sell"
                }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onBuySeeds, modifier = Modifier.weight(1f), enabled = game.money >= 80 + game.dailyLivingCost) { GameText("Buy seeds") }
            OutlinedButton(onClick = onPlant, modifier = Modifier.weight(1f), enabled = game.seedPacks > 0 && game.cropPlantedDay == null) { GameText("Plant bed") }
        }
        if (game.cropPlantedDay != null) {
            LinearProgressIndicator(progress = { ((game.day - game.cropPlantedDay).toFloat() / 4f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp))
        }
        if (game.cropReady) Button(onClick = onHarvest, modifier = Modifier.fillMaxWidth()) { GameText("Harvest 20 portions") }
        if (game.vegetables > 0) {
            GameText("Estimated market value: ${game.vegetables * 12} zł", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onSellVegetables, modifier = Modifier.fillMaxWidth()) { GameText("Sell harvest · ${game.vegetables * 12} zł") }
        }
    }
    InfoCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFF0E2D6)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Agriculture, null, tint = Color(0xFF805039), modifier = Modifier.size(29.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                GameText("Chicken coop", style = MaterialTheme.typography.titleLarge)
                GameText(if (game.coopBuilt) "${game.chickens}/4 hens · ${game.feedBags} feed bags" else "A basic timber coop and fenced run · 1,000 zł", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (!game.coopBuilt) {
            GameText("Build the coop first. Each healthy hen costs 220 zł. The small coop holds up to four.", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onBuildCoop, modifier = Modifier.fillMaxWidth(), enabled = game.money >= 1_000 + game.dailyLivingCost) { GameText("Build chicken coop · 1,000 zł") }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onBuyChicken, modifier = Modifier.weight(1f), enabled = game.chickens < 4 && game.money >= 220 + game.dailyLivingCost) { GameText("Buy hen · 220 zł") }
                OutlinedButton(onClick = onBuyFeed, modifier = Modifier.weight(1f), enabled = game.chickens > 0 && game.money >= 65 + game.dailyLivingCost) { GameText("Buy feed · 65 zł") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    GameText("Eggs in storage: ${game.eggs}", style = MaterialTheme.typography.titleMedium)
                    GameText("Feed the flock; every three days, each hen can lay two eggs.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (game.eggs > 0) Button(onClick = onSellEggs) { GameText("Sell · ${game.eggs * 3} zł") }
            }
        }
    }
    InfoCard {
        GameText("A realistic trade-off", style = MaterialTheme.typography.titleMedium)
        GameText("Farming costs time, water, feed and money. Small harvests add a little income but won't replace a job. Build your cash reserve before expanding.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** A custom, offline-rendered isometric property scene with ground, fencing, brickwork, roofing, trees and the player avatar. */
@Composable
private fun EstateScene(stage: Int, playerName: String, hasInventory: Boolean, modifier: Modifier = Modifier) {
    val sceneDescription = translateGameText("Your property and construction progress, phase ${stage} of 6", GameLanguageManager.code)
    Canvas(modifier.semantics { contentDescription = sceneDescription }) {
        val w = size.width
        val h = size.height
        fun p(x: Float, y: Float) = Offset(w * x, h * y)
        fun shape(points: List<Offset>, color: Color, stroke: Color? = null, strokeWidth: Float = 1f) {
            val path = Path().apply { moveTo(points[0].x, points[0].y); points.drop(1).forEach { lineTo(it.x, it.y) }; close() }
            drawPath(path, color)
            if (stroke != null) drawPath(path, stroke, style = Stroke(strokeWidth))
        }
        drawRect(brush = Brush.verticalGradient(listOf(Color(0xFFBDD0D5), Color(0xFFE0E2D3), Color(0xFF9AAF7A)), endY = h * .61f))
        // distant low hills and a soft rural horizon
        shape(listOf(p(0f,.39f),p(0f,.29f),p(.11f,.25f),p(.22f,.31f),p(.34f,.26f),p(.46f,.33f),p(.59f,.27f),p(.76f,.32f),p(.88f,.25f),p(1f,.29f),p(1f,.48f)), Color(0xFF849D79))
        shape(listOf(p(0f,.42f),p(.15f,.34f),p(.28f,.39f),p(.43f,.33f),p(.62f,.4f),p(.78f,.34f),p(1f,.4f),p(1f,1f),p(0f,1f)), Color(0xFF68845C))
        // patchy grass texture, deliberately deterministic so the world does not flicker
        for (i in 0 until 170) {
            val x = ((i * 73) % 997) / 997f
            val y = .38f + (((i * 37) % 599) / 599f) * .54f
            val c = when (i % 4) { 0 -> Color(0xFF9BB17C); 1 -> Color(0xFF526F4B); 2 -> Color(0xFF80996A); else -> Color(0xFF6E8B5B) }
            drawLine(c.copy(alpha = .52f), p(x,y), p(x + .004f, y - .008f), strokeWidth = 1.2f)
        }
        // public lane and compacted driveway
        shape(listOf(p(0f,.80f),p(.48f,.75f),p(1f,.82f),p(1f,1f),p(0f,1f)), Color(0xFF77786E))
        for (i in 0..34) drawLine(Color(0xFF999A8F).copy(alpha = .34f), p(i / 34f,.86f), p(i / 34f,.96f), strokeWidth = 1f)
        shape(listOf(p(.05f,.54f),p(.33f,.46f),p(.9f,.63f),p(.59f,.75f)), Color(0xFF7D9866), Color(0xFF476344), 1.4f)
        // fence posts and fine wire around the owned lot
        val fenceTop = listOf(p(.05f,.54f),p(.33f,.46f),p(.9f,.63f),p(.59f,.75f))
        fenceTop.forEachIndexed { index, point ->
            val next = fenceTop[(index + 1) % fenceTop.size]
            drawLine(Color(0xFFB8A27E), point, next, strokeWidth = 2.1f)
            for (post in 0..7) {
                val t = post / 7f
                val x = point.x + (next.x - point.x) * t
                val y = point.y + (next.y - point.y) * t
                drawLine(Color(0xFF6A513B), Offset(x,y), Offset(x, y - h * .025f), strokeWidth = 2.7f)
            }
        }
        // trees around, with trunk and overlapping foliage for a natural silhouette
        val trees = listOf(Triple(.08f,.36f,.045f), Triple(.17f,.39f,.036f), Triple(.89f,.39f,.05f), Triple(.96f,.44f,.034f), Triple(.73f,.32f,.033f))
        trees.forEachIndexed { index, (x,y,r) ->
            drawLine(Color(0xFF5C4936), p(x,y), p(x,y + .11f), strokeWidth = w * .012f)
            drawCircle(Color(0xFF36573D), radius = w*r, center = p(x,y))
            drawCircle(Color(0xFF52764C), radius = w*r*.76f, center = p(x-r*.24f,y-r*.18f))
            drawCircle(Color(0xFF739263), radius = w*r*.50f, center = p(x+r*.19f,y-r*.29f))
            drawCircle(Color(0xFF8BA278).copy(alpha=.34f), radius = w*r*.21f, center = p(x-r*.19f,y-r*.42f))
        }
        // piles of delivered brick and gravel near the entrance
        if (stage in 1..3 || hasInventory) {
            for (layer in 0..2) {
                val y = .635f - layer * .018f
                shape(listOf(p(.72f,.65f+layer*.003f),p(.78f,y),p(.83f,.65f+layer*.003f),p(.77f,.68f+layer*.003f)), Color(0xFF984F3B), Color(0xFF6D392D), 1f)
                for (j in 0..2) drawLine(Color(0xFFD9A18A).copy(alpha=.55f), p(.735f+j*.026f,y+.012f), p(.775f+j*.026f,y+.024f), strokeWidth = 1f)
            }
        }
        // construction pad with gravel texture
        shape(listOf(p(.35f,.55f),p(.55f,.46f),p(.77f,.57f),p(.56f,.68f)), Color(0xFFAAA597), Color(0xFF79786B), 1.3f)
        for (i in 0 until 80) {
            val x = .37f + ((i*61)%100)/100f*.37f
            val y = .52f + ((i*31)%100)/100f*.13f
            drawCircle(Color(0xFF78786D).copy(alpha=.45f), radius = w*.0017f, center = p(x,y))
        }
        // slab and house walls are drawn as physical planes rather than voxel blocks
        val a=p(.405f,.515f); val b=p(.588f,.435f); val c=p(.755f,.525f); val d=p(.573f,.608f)
        val wallBottomFrontA=p(.573f,.706f); val wallBottomFrontB=p(.755f,.623f); val wallBottomSide=p(.755f,.623f); val wallBottomBack=p(.588f,.533f)
        shape(listOf(a,b,c,d), if (stage >= 1) Color(0xFFB7B4AA) else Color(0xFF8F8D82), Color(0xFF65665F), 1.1f)
        if (stage >= 1) {
            shape(listOf(d,c,wallBottomSide,wallBottomFrontA), Color(0xFF8D8C83), Color(0xFF575B54), 1.4f)
            shape(listOf(c,b,wallBottomBack,wallBottomSide), Color(0xFFB9B2A3), Color(0xFF69675F), 1.4f)
            for (row in 0..5) {
                val t = row / 6f
                val y = .617f + t*.083f
                drawLine(Color(0xFF6D6D65).copy(alpha=.45f), p(.58f + t*.174f,y), p(.752f,y-.08f), strokeWidth = 1f)
            }
        }
        if (stage >= 2) {
            shape(listOf(a,d,wallBottomFrontA,p(.405f,.615f)), Color(0xFFAA6249), Color(0xFF744231), 1.3f)
            shape(listOf(d,c,wallBottomFrontB,wallBottomFrontA), Color(0xFFB7684C), Color(0xFF744231), 1.3f)
            shape(listOf(b,c,wallBottomFrontB,p(.588f,.533f)), Color(0xFF96543E), Color(0xFF6A392B), 1.3f)
            // mortar courses and staggered joints on visible planes
            for (row in 0..6) {
                val yf = .526f + row*.014f
                drawLine(Color(0xFFE2B39A).copy(alpha=.88f), p(.411f,yf), p(.573f,yf+.077f), strokeWidth = 1f)
                drawLine(Color(0xFFE2B39A).copy(alpha=.88f), p(.581f,yf+.08f), p(.75f,yf-.002f), strokeWidth = 1f)
                for (col in 0..4) {
                    val xx = .43f + col*.032f + if (row%2==0) 0f else .014f
                    drawLine(Color(0xFF784532).copy(alpha=.7f), p(xx,.526f+row*.014f), p(xx,.539f+row*.014f), strokeWidth = 1f)
                }
            }
        }
        if (stage >= 3) {
            // steep roof slopes with shingle / tile courses
            shape(listOf(p(.385f,.51f),p(.57f,.365f),p(.793f,.492f),p(.755f,.525f),p(.588f,.435f),p(.405f,.515f)), Color(0xFF633D31), Color(0xFF452D25), 1.2f)
            shape(listOf(p(.385f,.51f),p(.57f,.365f),p(.57f,.405f),p(.405f,.55f)), Color(0xFF845140), Color(0xFF583A2E), 1.2f)
            for (i in 1..5) {
                val y = .392f + i*.022f
                drawLine(Color(0xFFC08A6B).copy(alpha=.8f), p(.42f+(i*.003f),y+.125f-i*.014f), p(.567f,y-i*.004f), strokeWidth = 1.3f)
                drawLine(Color(0xFFB3785B).copy(alpha=.8f), p(.572f,y-i*.004f), p(.77f-i*.004f,y+.095f-i*.004f), strokeWidth = 1.2f)
            }
        }
        if (stage >= 4) {
            // dark glass window frames and the insulated front door
            shape(listOf(p(.438f,.557f),p(.467f,.57f),p(.467f,.599f),p(.438f,.586f)), Color(0xFF273F47), Color(0xFFE0D9C8), 2f)
            drawLine(Color(0xFF9DC4CB), p(.452f,.563f), p(.452f,.592f), strokeWidth = 1f)
            drawLine(Color(0xFF9DC4CB), p(.44f,.577f), p(.465f,.588f), strokeWidth = 1f)
            shape(listOf(p(.616f,.578f),p(.64f,.566f),p(.64f,.6f),p(.616f,.612f)), Color(0xFF294751), Color(0xFFDDD3BC), 2f)
            drawLine(Color(0xFFAAC9CD), p(.628f,.572f), p(.628f,.606f), strokeWidth = 1f)
            shape(listOf(p(.676f,.565f),p(.706f,.551f),p(.706f,.612f),p(.676f,.626f)), Color(0xFF684A33), Color(0xFFD8C7A5), 1.8f)
            drawCircle(Color(0xFFD5A84D), radius = w*.0025f, center = p(.699f,.594f))
        }
        if (stage >= 5) {
            shape(listOf(p(.405f,.515f),p(.588f,.435f),p(.755f,.525f),p(.573f,.608f)), Color(0xFFCFC6B3), Color(0xFF817966), 1.4f)
            shape(listOf(p(.405f,.515f),p(.573f,.608f),p(.573f,.625f),p(.405f,.532f)), Color(0xFF998F7E), Color(0xFF6D675B), 1f)
            shape(listOf(p(.573f,.608f),p(.755f,.525f),p(.755f,.542f),p(.573f,.625f)), Color(0xFF8D8575), Color(0xFF6D675B), 1f)
        }
        // avatar: natural proportions, separate torso, limbs, hair and a ground contact shadow
        drawOval(Color(0xFF28392B).copy(alpha=.22f), topLeft = p(.205f,.662f), size = Size(w*.078f,h*.014f))
        drawLine(Color(0xFF1F2823), p(.232f,.639f), p(.229f,.674f), strokeWidth = w*.012f, cap = StrokeCap.Round)
        drawLine(Color(0xFF1F2823), p(.25f,.639f), p(.259f,.674f), strokeWidth = w*.012f, cap = StrokeCap.Round)
        drawLine(Color(0xFFB67C58), p(.225f,.601f), p(.216f,.635f), strokeWidth = w*.008f, cap = StrokeCap.Round)
        drawLine(Color(0xFFB67C58), p(.253f,.601f), p(.266f,.632f), strokeWidth = w*.008f, cap = StrokeCap.Round)
        shape(listOf(p(.222f,.582f),p(.253f,.582f),p(.26f,.628f),p(.218f,.628f)), Color(0xFF344E58), Color(0xFF263B40), 1f)
        drawCircle(Color(0xFFC78D68), radius = w*.014f, center = p(.238f,.563f))
        drawArc(Color(0xFF42352B), 180f, 180f, false, topLeft = p(.224f,.549f), size = Size(w*.028f,h*.03f), style = Stroke(width=w*.005f))
        // garden beds and coop area are present from the beginning
        shape(listOf(p(.10f,.605f),p(.185f,.58f),p(.245f,.609f),p(.16f,.638f)), Color(0xFF6D4F38), Color(0xFF483728), 1f)
        for (row in 0..2) for (col in 0..4) {
            val x = .119f + col*.019f + row*.008f
            val y = .604f + row*.01f - col*.003f
            drawLine(Color(0xFF91B36C), p(x,y), p(x-.004f,y-.015f), strokeWidth = w*.003f, cap = StrokeCap.Round)
            drawLine(Color(0xFFB0C986), p(x,y), p(x+.006f,y-.013f), strokeWidth = w*.003f, cap = StrokeCap.Round)
        }
        // sun glare and subtle cloud texture
        drawCircle(Color.White.copy(alpha=.12f), radius = w*.075f, center = p(.83f,.13f))
        drawCircle(Color(0xFFE6D8B9).copy(alpha=.45f), radius = w*.045f, center = p(.82f,.12f))
    }
}
