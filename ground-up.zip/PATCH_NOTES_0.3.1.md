# Ground Up 0.3.1 patch notes

This patch addresses Kotlin compilation errors found by the GitHub Actions build of 0.3.0.

- `MainActivity` now extends `FragmentActivity`, which is the host type required by the installed AndroidX BiometricPrompt 1.1.0 API.
- Removed the explicit import of Compose `layout.weight`; it is resolved as a scope extension inside Row/Column content.
- Changed `InfoCard` content to `@Composable ColumnScope.() -> Unit`, matching the Compose `Column` content contract.
- Increased Android `versionCode` to 3 and `versionName` to 0.3.1.
- Removed the nested example GitHub workflow from the source archive. The authoritative ZIP-upload workflow is supplied separately.

## Verification status

The ZIP archive and expected project layout can be validated locally. This authoring environment cannot download Gradle dependencies/distributions because network DNS access is unavailable, so the patched Kotlin source has **not** been confirmed by a fresh Android build here. Run the supplied GitHub Actions workflow and share any remaining compile/test failures for the next correction.
