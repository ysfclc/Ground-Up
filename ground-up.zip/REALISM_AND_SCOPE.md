# Ground Up — realism and scope register

## What this build actually contains

- Native Android app using Kotlin and Jetpack Compose.
- Offline, deterministic first-chapter simulation: construction phases, jobs, energy, daily living costs, garden crops, chickens/eggs, inventory, a local event log and encrypted local saves.
- An isometric 2D property scene that changes with construction progress.
- A realistic human-proportioned starter-character portrait, used in the player header and profile panel. The player name is editable.
- English, Polish and Turkish language selection.
- A documented Polish material-price benchmark catalog; selected material rates have been rounded against dated references.
- A corrected work-energy gate: a shift cannot start unless the player has enough energy for that specific job.
- A visible save-warning banner after a persistence failure.

## What it does not claim to be yet

- It is **not** a navigable 3D open world and does not have real-time free movement.
- The portrait is a fixed starter avatar, not a full character creator. Face, skin tone, hair, body type, clothing and equipment customization are not implemented yet.
- NPCs with schedules, persistent relationships, dialogue choices and world routines are not implemented in this version.
- The current world does not yet simulate traffic, weather effects, property ownership markets, permits, contractors, tool wear or detailed skill progression.
- The price catalog is partial; several gameplay prices and all construction quantities still need verification against a specified house plan and bill of quantities.
- Android build and lint have not been run in this authoring container because Android SDK/Gradle are unavailable here. GitHub Actions is the authoritative build environment.

## Realistic visual direction

The game should use grounded materials, believable proportions, restrained UI, natural lighting and realistic human characters. Avoid chibi proportions, toy-like props, exaggerated facial features, oversaturated cartoon colors and fake claims of photorealistic 3D. The current property illustration remains stylized 2D; the character portrait is realistic. A true 3D environment would require a separate engine/rendering migration and should not be implied by this Compose build.

## Next architecture milestone

1. Define a world model: locations, travel time, world clock, weather, time-of-day and location-specific services.
2. Add a deterministic NPC model: identity, schedule, role, dialogue topics, relationship state and event history.
3. Add character-creation state and persist selected appearance attributes.
4. Replace hard-coded construction packages with a versioned bill-of-quantities model, price provenance and price freshness.
5. Add save schema migrations before expanding persisted state.
6. Introduce integration/UI tests and test the app on at least one physical Android device.
