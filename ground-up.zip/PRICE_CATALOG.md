# Ground Up — Polish material-price reference catalog

**Reference date:** 25 October 2026  
**Currency:** PLN, gross prices where the cited source specifies gross prices  
**Region:** Poland; local availability, delivery, quantity discounts, VAT treatment and product specification can change the actual price.

This is a transparent benchmark catalog, not a live store API. Prices in the game are rounded to whole PLN to keep the existing simulation economy simple. Only the rows marked **benchmarked** below were updated against the linked references; the remaining game prices are still **balancing estimates** and must not be presented as sourced quotations.

| Game material | Game price | Reference price | Basis / status | Source |
|---|---:|---:|---|---|
| Ready-mix concrete C20/25 | 517 PLN/m³ | 516.51 PLN/m³ | Rounded gross price; benchmarked | [Budowlane AI price table](https://budowlaneai.pl/prices), updated 25 Oct 2026 |
| Steel reinforcement B500 | 5 PLN/kg | 4.51 PLN/kg | Rounded gross price; benchmarked | [Budowlane AI price table](https://budowlaneai.pl/prices), updated 25 Oct 2026 |
| Ceramic masonry units | 7 PLN/unit | 7.44 PLN/unit for a 25 cm ceramic hollow block | Rounded benchmark; the game unit is a simplified masonry unit, not a guaranteed exact product match | [Budowlane AI price table](https://budowlaneai.pl/prices), updated 25 Oct 2026 |
| Masonry mortar, 25 kg | 17 PLN/bag | 16.99 PLN/bag | Rounded gross retail listing; benchmarked | [Leroy Merlin Poland — 25 kg masonry mortar](https://www.leroymerlin.pl/produkty/budowa/beton-cement-zaprawa-tynk/cementy-i-wapna/cement-25kg-p.html) |
| Structural timber | 2,310 PLN/m³ | 2,310 PLN/m³ | Benchmark from a reported Polish price table; actual grade and dimensions vary | [CennikiBudowlane — September 2026 price report](https://cennikibudowlane.com.pl/blog/ceny-materialow-budowlanych-wrzesien-2026/) |
| Ceramic roof tiles | 59 PLN/m² | 59.20 PLN/m² | Rounded gross price; benchmarked | [Budowlane AI price table](https://budowlaneai.pl/prices), updated 25 Oct 2026 |
| Double-glazed window | 1,750 PLN/unit | 1,750 PLN/unit average for a medium three-pane PVC window | Benchmark only; dimensions, glazing, fittings and installation vary | [CennikiBudowlane — September 2026 price report](https://cennikibudowlane.com.pl/blog/ceny-materialow-budowlanych-wrzesien-2026/) |

## Still estimated in the game

Mini-excavator hire, gravel, formwork, lintels, roofing membrane, cable, pipe, entrance door, plaster, floor finish, paint, living costs, job wages, seeds, livestock, feed and produce prices remain simulation/balancing values. They are not live quotations. Before claiming the full construction budget is realistic, the next pass must source each of these by specification and unit, normalize VAT/delivery assumptions, and review quantities against a defined house design and bill of quantities.

## Important limitation

The game is offline. These reference values do not automatically update, do not guarantee a local store price, and do not place orders. The first playable chapter still uses simplified construction packages and whole-PLN arithmetic. This catalog records what was checked so the game does not silently present every number as a current, verified market price.
