# Ground Up — Real-Life Simulation for Android

Ground Up is an offline Android life simulation about making a living and building a real-world-style home from the ground up. The player is represented by a named avatar on a 420 m² plot. Money, time, materials, energy, housing costs, work, farming, livestock and market sales interact through deterministic rules.

## Languages

The game includes English, Polish (**Polski**) and Turkish (**Türkçe**). It follows the phone's language when starting a new game if Android is configured for Polish or Turkish; English is the fallback. The language can also be changed in the avatar/game-settings dialog. The selection is stored with the local save and survives a restart.

## Playable features

- A custom-drawn isometric property scene that changes as construction progresses.
- Six construction phases: site preparation, foundations, brickwork, roof, windows/services, and interior finish.
- Material quantities using physical-style units (for example m³, kg, pieces, m²) with estimated Polish-złoty prices.
- Three jobs with different pay and energy costs; rest, daily expenses and wellbeing create trade-offs.
- A garden with a four-day growing cycle, harvest and market sale.
- A small chicken coop with up to four hens, feed consumption, egg production and sales.
- Avatar renaming, language selection, recent-life event log and a confirmed reset.
- Offline play and local save data encrypted with AES-256-GCM using a non-exportable Android Keystore key.
- No analytics, account, cloud dependency, network permission, NFT, crypto-wallet or real-money trading features.

This is a first playable simulation chapter, not a finished open-world 3D game. The current property view is custom-drawn 2D/isometric artwork; the materials and costs are simulated estimates, not live supplier quotations. Real construction or physical purchasing is not triggered by game actions.

## Build requirements

- Android SDK Platform 35 and Build Tools 35.0.0.
- JDK 17.
- Gradle 8.10.2 (the supplied `gradlew` downloads the official distribution on first use and checks its SHA-256 checksum).
- Internet access for the initial Gradle/Maven dependency download, unless those artifacts are already cached.
- Android 11 / API 30 or newer.

The project uses Kotlin 2.0.21, Jetpack Compose, Material 3 and Android Gradle Plugin 8.7.3.

## Build and install locally

Extract the archive, enter the `ground-up/` directory, then run:

```bash
./gradlew testDebugUnitTest
./gradlew lintDebug
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Alternatively, copy `app/build/outputs/apk/debug/app-debug.apk` to your phone and open it. Allow installation from that file source if Android requests it. The debug APK is signed for immediate testing; it is not a Play Store release artifact.

## GitHub ZIP workflow

This project is packaged with a top-level `ground-up/` directory to work with an archive-driven GitHub Actions flow:

1. Upload this archive to your repository root with the exact filename `ground-up.zip`.
2. Upload the companion workflow as `.github/workflows/build-apk.yml`.
3. The workflow extracts `ground-up.zip`, verifies `ground-up/settings.gradle.kts` and `ground-up/app/build.gradle.kts`, runs unit tests and Android lint, builds the debug APK, and uploads it as the `ground-up-debug-apk` artifact.

Replace `ground-up.zip` with a new version to trigger another build. The ZIP archive is the source payload; the separately uploaded workflow is what GitHub executes. You do not need Android signing secrets for a debug APK.

## Architecture and data protection

- `GameState` is the serializable game state; `GameEngine` contains deterministic and testable economic rules.
- `GameViewModel` runs save/load on an IO dispatcher and exposes UI state through `StateFlow`.
- `EncryptedGameStore` encrypts the local JSON save with AES-256-GCM. The key is generated in Android Keystore and is not exportable from the app.
- Save files live in the app-private `noBackupFilesDir`; Android cloud/device-transfer backups are disabled.
- The game is fully playable offline. Prices are illustrative and are not connected to a live market.

## Testing and verification boundary

Unit tests cover the main economy loop (work, daily cost, building prerequisites, material inventory, crop cycle and completed-home rent reduction) and the English/Polish/Turkish text selection and dynamic labels. An Android compile must run on a machine or CI runner with the Android SDK and access to Gradle/Maven dependencies.
