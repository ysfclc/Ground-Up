package com.groundup.game.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import com.groundup.game.data.GameState
import org.junit.Test

class GameLanguageTest {
    @Test fun translatesCoreNavigationAndConstructionTermsToPolish() {
        assertEquals("Świat", translateGameText("World", "pl"))
        assertEquals("Fundamenty", translateGameText("Foundation", "pl"))
        assertEquals("Cegły ceramiczne", translateGameText("Ceramic bricks", "pl"))
    }

    @Test fun translatesCoreNavigationAndConstructionTermsToTurkish() {
        assertEquals("Dünya", translateGameText("World", "tr"))
        assertEquals("Temel", translateGameText("Foundation", "tr"))
        assertEquals("Seramik tuğla", translateGameText("Ceramic bricks", "tr"))
    }

    @Test fun dynamicDayAndEnergyCountersKeepTheirValues() {
        assertEquals("DZIEŃ 7", translateGameText("DAY 7", "pl"))
        assertEquals("GÜN 7", translateGameText("DAY 7", "tr"))
        assertEquals("ENERGIA 65%", translateGameText("ENERGY 65%", "pl"))
        assertEquals("ENERJİ 65%", translateGameText("ENERGY 65%", "tr"))
    }

    @Test fun unknownUserNamesArePreserved() {
        assertEquals("Patrycja", translateGameText("Patrycja", "pl"))
        assertEquals("Yusuf", translateGameText("Yusuf", "tr"))
    }

    @Test fun gameLanguageIsPartOfSavedStateAndValidated() {
        assertEquals("pl", GameState(languageCode = "pl").safe().languageCode)
        assertEquals("tr", GameState(languageCode = "tr").safe().languageCode)
    }

    @Test fun dynamicGamePricesAndQuantitiesTranslate() {
        assertEquals("Zamów brakujące materiały · 3 120 zł", translateGameText("Order missing materials · 3 120 zł", "pl"))
        assertEquals("Depodaki yumurta: 6", translateGameText("Eggs in storage: 6", "tr"))
    }

    @Test fun englishRemainsUnchanged() {
        assertEquals("Build a life from the ground up", translateGameText("Build a life from the ground up", "en"))
    }

    @Test fun languageOptionsContainPolishAndTurkish() {
        assertTrue(GAME_LANGUAGES.any { it.code == "pl" && it.nativeName == "Polski" })
        assertTrue(GAME_LANGUAGES.any { it.code == "tr" && it.nativeName == "Türkçe" })
    }
}
