package com.groundup.game.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineTest {
    @Test fun workPaysAndAdvancesTheDayWithLivingCosts() {
        val start = GameState(money = 2_000, energy = 100)
        val result = GameEngine.work(start, "warehouse")
        assertEquals(2, result.day)
        assertEquals(2_445, result.money) // +590 wage, -145 living costs
        assertEquals(74, result.energy)
    }

    @Test fun aConstructionPhaseCannotAdvanceWithoutMaterials() {
        val result = runCatching { GameEngine.buildNextStage(GameState()) }
        assertTrue(result.isFailure)
        assertEquals(0, GameState().homeStage)
    }

    @Test fun materialsArePurchasedAndConsumedAsACompleteStagePackage() {
        var state = GameState(money = 20_000)
        state = GameEngine.buyMaterials(state)
        assertEquals(2, state.day)
        assertEquals(16_735, state.money) // 20,000 - 3,120 materials - 145 living costs
        assertEquals(1, state.inventory["excavator_day"])
        state = GameEngine.buildNextStage(state)
        assertEquals(1, state.homeStage)
        assertEquals(3, state.day)
        assertEquals(16_590, state.money)
        assertEquals(0, state.inventory["gravel_t"])
    }

    @Test fun unaffordableMaterialOrderDoesNotChangeTheSave() {
        val start = GameState(money = 100)
        val result = runCatching { GameEngine.buyMaterials(start) }
        assertTrue(result.isFailure)
        assertEquals(start, GameState(money = 100))
    }

    @Test fun cropsNeedFourDaysBeforeHarvestAndCanBeSoldOnce() {
        var state = GameState(money = 2_000, seedPacks = 1)
        state = GameEngine.plantSeeds(state)
        repeat(3) { state = GameEngine.rest(state) }
        assertFalse(state.cropReady)
        state = GameEngine.rest(state)
        assertTrue(state.cropReady)
        state = GameEngine.harvest(state)
        assertEquals(20, state.vegetables)
        state = GameEngine.sellVegetables(state)
        assertEquals(0, state.vegetables)
        assertEquals(1_225, state.money) // 2,000 - eight daily costs + 240 sale proceeds
    }

    @Test fun completedHomeRemovesRentFromDailyCosts() {
        val state = GameState(homeStage = 6)
        assertTrue(state.ownsHome)
        assertEquals(85, state.dailyLivingCost)
    }
}
