package com.groundup.game.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

 data class GameUiState(
    val game: GameState = GameState(),
    val loading: Boolean = false,
    val hasLoaded: Boolean = false,
    val saving: Boolean = false,
    val storageError: String? = null,
    val notice: String? = null,
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val store = EncryptedGameStore(application.applicationContext)
    private val mutable = MutableStateFlow(GameUiState())
    val state: StateFlow<GameUiState> = mutable.asStateFlow()
    private var revision = 0L

    fun loadIfNeeded() {
        if (mutable.value.hasLoaded || mutable.value.loading) return
        mutable.update { it.copy(loading = true, storageError = null) }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.load() } }
            result.fold(
                onSuccess = { game -> mutable.update { it.copy(game = game, loading = false, hasLoaded = true, storageError = null) } },
                onFailure = { error -> mutable.update { it.copy(loading = false, hasLoaded = false, storageError = error.message ?: "The save could not be opened.") } },
            )
        }
    }

    fun retryLoad() { mutable.update { it.copy(hasLoaded = false, storageError = null) }; loadIfNeeded() }

    fun work(jobId: String) = act { GameEngine.work(it, jobId) }
    fun rest() = act(GameEngine::rest)
    fun buyMaterials() = act(GameEngine::buyMaterials)
    fun buildNextStage() = act(GameEngine::buildNextStage)
    fun buySeeds() = act(GameEngine::buySeeds)
    fun plantSeeds() = act(GameEngine::plantSeeds)
    fun harvest() = act(GameEngine::harvest)
    fun sellVegetables() = act(GameEngine::sellVegetables)
    fun buildCoop() = act(GameEngine::buildCoop)
    fun buyChicken() = act(GameEngine::buyChicken)
    fun buyFeed() = act(GameEngine::buyFeed)
    fun sellEggs() = act(GameEngine::sellEggs)
    fun rename(name: String) = act { GameEngine.rename(it, name) }

    fun setLanguage(code: String) {
        val normalized = code.lowercase().takeIf { it in setOf("en", "pl", "tr") } ?: return
        if (mutable.value.game.languageCode == normalized) return
        mutable.update { it.copy(game = it.game.copy(languageCode = normalized), notice = null) }
        persist()
    }

    fun resetGame() {
        val languageCode = mutable.value.game.languageCode
        mutable.update { it.copy(game = GameState(languageCode = languageCode), notice = "A new life has begun.", storageError = null, hasLoaded = true) }
        persist()
    }

    fun clearNotice() = mutable.update { it.copy(notice = null) }

    private fun act(operation: (GameState) -> GameState) {
        val current = mutable.value
        if (!current.hasLoaded || current.loading) return
        runCatching { operation(current.game).safe() }
            .onSuccess { updated ->
                mutable.update { it.copy(game = updated, notice = updated.log.firstOrNull(), storageError = null) }
                persist()
            }
            .onFailure { error -> mutable.update { it.copy(notice = error.message ?: "That action couldn't be completed.") } }
    }

    private fun persist() {
        val snapshot = mutable.value.game
        val localRevision = ++revision
        mutable.update { it.copy(saving = true) }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.save(localRevision, snapshot) } }
            result.fold(
                onSuccess = { mutable.update { it.copy(saving = false, storageError = null) } },
                onFailure = { error -> mutable.update { it.copy(saving = false, storageError = error.message ?: "Your progress could not be saved.") } },
            )
        }
    }
}
