package com.groundup.game

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.groundup.game.ui.GroundUpApp
import com.groundup.game.ui.GroundUpTheme
import com.groundup.game.ui.GameText

class MainActivity : ComponentActivity() {
    private var unlockState: androidx.compose.runtime.MutableState<Boolean>? = null
    private var lastPausedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val unlocked = remember { mutableStateOf(false) }
            var authMessage by remember { mutableStateOf<String?>(null) }
            unlockState = unlocked
            GroundUpTheme {
                if (unlocked.value) {
                    GroundUpApp()
                } else {
                    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(84.dp)) {
                                Icon(Icons.Filled.Home, contentDescription = null, modifier = Modifier.padding(19.dp), tint = MaterialTheme.colorScheme.onPrimary)
                            }
                            Spacer(Modifier.height(22.dp))
                            GameText("GROUND UP", style = MaterialTheme.typography.headlineLarge)
                            Spacer(Modifier.height(8.dp))
                            GameText("Your life. Your land. Your choices.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(24.dp))
                            GameText("Unlock with your phone's biometric or secure screen lock. Your saved world stays encrypted on this device.", style = MaterialTheme.typography.bodyMedium)
                            if (authMessage != null) {
                                Spacer(Modifier.height(12.dp))
                                GameText(authMessage!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                            Spacer(Modifier.height(18.dp))
                            Button(onClick = { requestAuthentication { success, message -> unlocked.value = success; authMessage = message } }) {
                                GameText("Unlock game")
                            }
                            OutlinedButton(onClick = {
                                runCatching { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
                            }) { GameText("Phone security settings") }
                        }
                    }
                }
            }
            LaunchedEffect(Unit) {
                requestAuthentication { success, message ->
                    unlocked.value = success
                    authMessage = message
                }
            }
        }
    }

    override fun onPause() {
        lastPausedAt = SystemClock.elapsedRealtime()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (lastPausedAt > 0L) {
            val duration = SystemClock.elapsedRealtime() - lastPausedAt
            if (duration >= RELOCK_AFTER_MILLIS) unlockState?.value = false
            lastPausedAt = 0L
        }
    }

    private fun requestAuthentication(onResult: (Boolean, String?) -> Unit) {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val availability = BiometricManager.from(this).canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
            onResult(false, when (availability) {
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "Set up a fingerprint, face unlock or secure screen lock in Android Settings first."
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "This device has no supported biometric hardware. Set up a secure screen lock instead."
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "Security hardware is temporarily unavailable. Try again."
                else -> "A secure screen lock is required to open your saved world."
            })
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onResult(true, null) }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                onResult(false, when (errorCode) {
                    BiometricPrompt.ERROR_USER_CANCELED, BiometricPrompt.ERROR_NEGATIVE_BUTTON -> "Unlock cancelled. Your save remains protected."
                    BiometricPrompt.ERROR_LOCKOUT, BiometricPrompt.ERROR_LOCKOUT_PERMANENT -> "Too many attempts. Unlock your phone and try again."
                    else -> errString.toString()
                })
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Ground Up")
            .setSubtitle("Verify it's you to load your saved world.")
            .setAllowedAuthenticators(authenticators)
            .build()
        runCatching { prompt.authenticate(info) }.onFailure { onResult(false, "Could not start secure unlock. Check your phone's screen-lock settings.") }
    }

    companion object { private const val RELOCK_AFTER_MILLIS = 300_000L }
}
