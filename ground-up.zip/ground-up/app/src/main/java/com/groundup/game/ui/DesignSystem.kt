package com.groundup.game.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape

/** The sole source of design tokens for Ground Up. */
object EarthTokens {
    val soil = Color(0xFF77523B)
    val clay = Color(0xFFB65B3F)
    val leaf = Color(0xFF42634A)
    val sun = Color(0xFFD5A84D)
    val lightBackground = Color(0xFFF4F1E9)
    val darkBackground = Color(0xFF171B18)
    val lightSurface = Color(0xFFFFFDF8)
    val darkSurface = Color(0xFF222823)
    val lightText = Color(0xFF252923)
    val darkText = Color(0xFFE9EDE6)
    val quiet = Color(0xFF687165)
    val spacing = listOf(4.dp, 8.dp, 12.dp, 16.dp, 20.dp, 24.dp, 32.dp)
    val radiusSmall = 10.dp
    val radiusMedium = 16.dp
    val radiusLarge = 22.dp
    val touch = 48.dp
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF36573D), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE9D8), onPrimaryContainer = Color(0xFF17351F),
    secondary = Color(0xFF805039), onSecondary = Color.White,
    secondaryContainer = Color(0xFFF1DDCF), onSecondaryContainer = Color(0xFF4B2918),
    tertiary = Color(0xFF795A13), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFF5E4AC), onTertiaryContainer = Color(0xFF352600),
    background = EarthTokens.lightBackground, onBackground = EarthTokens.lightText,
    surface = EarthTokens.lightSurface, onSurface = EarthTokens.lightText,
    surfaceVariant = Color(0xFFE8E6DD), onSurfaceVariant = Color(0xFF444A41),
    outline = Color(0xFF74796F), outlineVariant = Color(0xFFD2D3C8),
    error = Color(0xFFBA1A1A), onError = Color.White,
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFFB3D3B0), onPrimary = Color(0xFF1C3923),
    primaryContainer = Color(0xFF2C4D33), onPrimaryContainer = Color(0xFFD0EBD0),
    secondary = Color(0xFFE8BFA8), onSecondary = Color(0xFF4A2B1A),
    secondaryContainer = Color(0xFF653F2C), onSecondaryContainer = Color(0xFFFFDBCA),
    tertiary = Color(0xFFE7C875), onTertiary = Color(0xFF3E2F00),
    tertiaryContainer = Color(0xFF594500), onTertiaryContainer = Color(0xFFFFE7A0),
    background = EarthTokens.darkBackground, onBackground = EarthTokens.darkText,
    surface = EarthTokens.darkSurface, onSurface = EarthTokens.darkText,
    surfaceVariant = Color(0xFF343B34), onSurfaceVariant = Color(0xFFCBD1C5),
    outline = Color(0xFF8A9286), outlineVariant = Color(0xFF454D45),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
)
private val GroundTypography = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp, letterSpacing = (-0.7).sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.4).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 23.sp, lineHeight = 29.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.Default, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.Default, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.Default, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp),
)

@Composable
fun GroundUpTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = GroundTypography,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(6.dp), small = RoundedCornerShape(EarthTokens.radiusSmall),
            medium = RoundedCornerShape(EarthTokens.radiusMedium), large = RoundedCornerShape(EarthTokens.radiusLarge),
            extraLarge = RoundedCornerShape(28.dp),
        ),
        content = content,
    )
}
