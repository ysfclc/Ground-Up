package com.groundup.game.ui

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text as MaterialText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.TextUnit
import java.util.Locale

/** User-selectable game language. Labels are intentionally in each language's own spelling. */
data class GameLanguageOption(val code: String, val nativeName: String)
val GAME_LANGUAGES = listOf(
    GameLanguageOption("en", "English"),
    GameLanguageOption("pl", "Polski"),
    GameLanguageOption("tr", "Türkçe"),
)

private fun systemGameLanguage(): String = when (Locale.getDefault().language.lowercase(Locale.ROOT)) {
    "pl" -> "pl"
    "tr" -> "tr"
    else -> "en"
}

object GameLanguageManager {
    var code by mutableStateOf(systemGameLanguage())
        private set

    fun set(code: String) {
        this.code = code.lowercase(Locale.ROOT).takeIf { it in setOf("en", "pl", "tr") } ?: systemGameLanguage()
    }
}

/**
 * One entry point for visible game text. Game state and save data remain language-neutral; labels,
 * descriptions, feedback and the event log are translated for the selected UI language.
 */
@Composable
fun GameText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    style: TextStyle = LocalTextStyle.current,
    fontWeight: FontWeight? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    maxLines: Int = Int.MAX_VALUE,
    softWrap: Boolean = true,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    MaterialText(
        text = translateGameText(text, GameLanguageManager.code),
        modifier = modifier,
        color = color,
        style = style,
        fontWeight = fontWeight,
        letterSpacing = letterSpacing,
        maxLines = maxLines,
        softWrap = softWrap,
        overflow = overflow,
    )
}

fun translateGameText(source: String, languageCode: String): String {
    val code = languageCode.lowercase(Locale.ROOT)
    if (code == "en" || code !in setOf("pl", "tr")) return source
    val text = source.trim()
    val key = text.lowercase(Locale.ROOT)
    val dictionary = if (code == "pl") polish else turkish
    dictionary[key]?.let { translation ->
        return if (text.any { it.isLetter() } && text == text.uppercase(Locale.ROOT)) {
            translation.uppercase(Locale.forLanguageTag(code))
        } else translation
    }

    // Dynamic copy is translated by shape so values remain live and do not become stale strings.
    Regex("^DAY (\\d+)$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "DZIEŃ ${it.groupValues[1]}" else "GÜN ${it.groupValues[1]}"
    }
    Regex("^ENERGY (\\d+)%$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "ENERGIA ${it.groupValues[1]}%" else "ENERJİ ${it.groupValues[1]}%"
    }
    Regex("^(\\d+) days remaining$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Pozostało dni: ${it.groupValues[1]}" else "Kalan gün: ${it.groupValues[1]}"
    }
    Regex("^Growing · (\\d+) days remaining$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Rośnie · pozostało dni: ${it.groupValues[1]}" else "Büyüyor · kalan gün: ${it.groupValues[1]}"
    }
    Regex("^Harvest stored · (\\d+) portions$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Zebrane warzywa · ${it.groupValues[1]} porcji" else "Hasat depoda · ${it.groupValues[1]} porsiyon"
    }
    Regex("^Build (.+)$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val stage = translateGameText(it.groupValues[1], code)
        return if (code == "pl") "Buduj: $stage" else "İnşa et: $stage"
    }
    Regex("^(.+) · material order$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val stage = translateGameText(it.groupValues[1], code)
        return if (code == "pl") "$stage · zamówienie materiałów" else "$stage · malzeme siparişi"
    }
    Regex("^You completed a (.+) and earned (\\d+) zł\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val job = translateGameText(it.groupValues[1], code)
        return if (code == "pl") "Ukończono zmianę: $job. Zarobek: ${it.groupValues[2]} zł." else "$job işi tamamlandı. Kazanç: ${it.groupValues[2]} zł."
    }
    Regex("^Your hens laid (\\d+) eggs\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Kury zniosły ${it.groupValues[1]} jaj." else "Tavukların ${it.groupValues[1]} yumurta yaptı."
    }
    Regex("^Sold your vegetables at the local market for (\\d+) zł\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Sprzedano warzywa na lokalnym targu za ${it.groupValues[1]} zł." else "Sebzeler yerel pazarda ${it.groupValues[1]} zł karşılığında satıldı."
    }
    Regex("^Sold (\\d+) eggs at 3 zł each · (\\d+) zł\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Sprzedano ${it.groupValues[1]} jaj po 3 zł za sztukę · ${it.groupValues[2]} zł." else "${it.groupValues[1]} yumurta tanesi 3 zł'den satıldı · ${it.groupValues[2]} zł."
    }
    Regex("^Daily living costs were (\\d+) zł\\. You couldn't cover everything\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Codzienne koszty wyniosły ${it.groupValues[1]} zł. Nie udało się pokryć wszystkich wydatków." else "Günlük yaşam giderleri ${it.groupValues[1]} zł oldu. Tüm masraflar karşılanamadı."
    }
    Regex("^Materials delivered for (.+) · (\\d+) zł\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val stage = translateGameText(it.groupValues[1], code)
        return if (code == "pl") "Dostarczono materiały do etapu: $stage · ${it.groupValues[2]} zł." else "$stage aşaması için malzemeler teslim edildi · ${it.groupValues[2]} zł."
    }
    Regex("^Living costs: (\\d+) zł per day$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Koszty życia: ${it.groupValues[1]} zł dziennie" else "Günlük yaşam gideri: ${it.groupValues[1]} zł"
    }
    Regex("^Current savings: (\\d+) zł$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Obecne oszczędności: ${it.groupValues[1]} zł" else "Mevcut birikim: ${it.groupValues[1]} zł"
    }
    Regex("^Estimated market value: (\\d+) zł$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Szacowana wartość na targu: ${it.groupValues[1]} zł" else "Tahmini pazar değeri: ${it.groupValues[1]} zł"
    }
    Regex("^Sell harvest · (\\d+) zł$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Sprzedaj plony · ${it.groupValues[1]} zł" else "Hasadı sat · ${it.groupValues[1]} zł"
    }
    Regex("^Sell · (\\d+) zł$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Sprzedaj · ${it.groupValues[1]} zł" else "Sat · ${it.groupValues[1]} zł"
    }
    Regex("^(\\d+)/4 hens · (\\d+) feed bags$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Kury: ${it.groupValues[1]}/4 · worki paszy: ${it.groupValues[2]}" else "Tavuk: ${it.groupValues[1]}/4 · yem çuvalı: ${it.groupValues[2]}"
    }
    Regex("^(\\d+)% available$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Dostępne: ${it.groupValues[1]}%" else "Mevcut: %${it.groupValues[1]}"
    }
    Regex("^You need (\\d+) zł and must keep (\\d+) zł for today's living costs\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Potrzebujesz ${it.groupValues[1]} zł i musisz zachować ${it.groupValues[2]} zł na dzisiejsze koszty życia." else "${it.groupValues[1]} zł gerekiyor; bugünün yaşam giderleri için ${it.groupValues[2]} zł ayırmalısın."
    }
    Regex("^The order costs (\\d+) zł\\. Keep at least (\\d+) zł for daily living costs\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Zamówienie kosztuje ${it.groupValues[1]} zł. Zachowaj co najmniej ${it.groupValues[2]} zł na codzienne koszty życia." else "Sipariş ${it.groupValues[1]} zł tutuyor. Günlük giderler için en az ${it.groupValues[2]} zł ayır."
    }
    Regex("^You need (\\d+) zł, plus money for daily living costs\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Potrzebujesz ${it.groupValues[1]} zł oraz pieniędzy na codzienne koszty życia." else "${it.groupValues[1]} zł ve günlük yaşam giderleri için ek para gerekiyor."
    }
    Regex("^The coop costs 1,000 zł\\. Keep money for daily living costs\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Kurnik kosztuje 1 000 zł. Zachowaj pieniądze na codzienne koszty życia." else "Kümes 1.000 zł tutuyor. Günlük giderler için para ayır."
    }
    Regex("^Materials are missing\\. Order the (.+) package first\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val stage = translateGameText(it.groupValues[1], code)
        return if (code == "pl") "Brakuje materiałów. Najpierw zamów zestaw: $stage." else "Malzemeler eksik. Önce $stage paketini sipariş et."
    }
    Regex("^(.+) complete · (\\d+) days of work represented\\.$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val stage = translateGameText(it.groupValues[1], code)
        return if (code == "pl") "Ukończono etap: $stage · praca trwała ${it.groupValues[2]} dni." else "$stage tamamlandı · çalışma süresi ${it.groupValues[2]} gün olarak işlendi."
    }
    Regex("^Your property and construction progress, phase (\\d+) of 6$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Twoja działka i postęp budowy, etap ${it.groupValues[1]} z 6" else "Arazin ve inşaat ilerlemen, 6 aşamadan ${it.groupValues[1]}. aşama"
    }
    Regex("^Order missing materials · ([0-9][0-9 ]*) zł$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Zamów brakujące materiały · ${it.groupValues[1]} zł" else "Eksik malzemeleri sipariş et · ${it.groupValues[1]} zł"
    }
    Regex("^Eggs in storage: (\\d+)$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        return if (code == "pl") "Jajka w magazynie: ${it.groupValues[1]}" else "Depodaki yumurta: ${it.groupValues[1]}"
    }
    Regex("^(\\d+) day(s)?$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val n = it.groupValues[1]
        return if (code == "pl") "$n ${if (n == "1") "dzień" else "dni"}" else "$n gün"
    }
    Regex("^(\\d+) (pieces|piece|kg|m³|m²|metres|litres|tonnes|rolls|units|unit|set|days|day|25 kg bags) × (\\d+) zł$", RegexOption.IGNORE_CASE).matchEntire(text)?.let {
        val qty = it.groupValues[1]
        val unit = translateGameText(it.groupValues[2], code)
        val price = it.groupValues[3]
        return "$qty $unit × $price zł"
    }
    return source
}

private val polish = mapOf(
    "loading your life…" to "Wczytywanie Twojego życia…",
    "your save couldn't be opened" to "Nie udało się otworzyć zapisu gry",
    "try again" to "Spróbuj ponownie",
    "start a new life" to "Rozpocznij nowe życie",
    "starting a new life replaces the unreadable save." to "Rozpoczęcie nowego życia zastąpi nieczytelny zapis.",
    "a life, built by you" to "ŻYCIE ZBUDOWANE PRZEZ CIEBIE",
    "avatar and game settings" to "Ustawienia awatara i gry",
    "your life" to "Twoje życie",
    "the avatar represents you in this world. your progress is saved on this device." to "Awatar reprezentuje Ciebie w tym świecie. Postępy są zapisywane na tym urządzeniu.",
    "avatar name" to "Imię awatara",
    "your save is encrypted on-device. no account or network connection is used." to "Zapis jest szyfrowany na urządzeniu. Konto ani połączenie z siecią nie są potrzebne.",
    "language" to "Język",
    "start over" to "Zacznij od nowa",
    "save avatar" to "Zapisz awatar",
    "cancel" to "Anuluj",
    "start a new life?" to "Rozpocząć nowe życie?",
    "this permanently replaces your current local save with a new plot, new budget and day 1. there is no undo." to "To trwale zastąpi bieżący zapis nową działką, budżetem i dniem 1. Nie można tego cofnąć.",
    "reset life" to "Zresetuj życie",
    "keep playing" to "Graj dalej",
    "world" to "Świat",
    "work" to "Praca",
    "market" to "Targ",
    "farm" to "Gospodarstwo",
    "simulated local economy · prices are game estimates, not live quotes" to "SYMULOWANA GOSPODARKA · CENY SĄ SZACUNKAMI W GRZE, NIE AKTUALNYMI OFERTAMI",
    "your property · 420 m²" to "TWOJA DZIAŁKA · 420 m²",
    "build a life from the ground up" to "Zbuduj życie od podstaw",
    "a plot, a budget, and real-world choices. every day costs money." to "Działka, budżet i decyzje z prawdziwego życia. Każdy dzień kosztuje.",
    "your plot" to "TWOJA DZIAŁKA",
    "your own home" to "Twój własny dom",
    "small starter house" to "Mały dom na start",
    "saving" to "Zapisywanie",
    "saved" to "Zapisano",
    "wellbeing" to "SAMOPOCZUCIE",
    "home" to "DOM",
    "daily cost" to "KOSZT DZIENNY",
    "a home of your own." to "Własny dom.",
    "you've completed the starter house. rent is gone; your daily living costs are lower. keep working on your land, garden and flock." to "Ukończono dom na start. Nie płacisz już czynszu, a codzienne koszty są niższe. Rozwijaj działkę, ogród i hodowlę.",
    "visit local market" to "Odwiedź lokalny targ",
    "next construction phase" to "NASTĘPNY ETAP BUDOWY",
    "materials ready" to "Materiały gotowe",
    "materials still needed" to "Brakujące materiały",
    "ready" to "GOTOWE",
    "not ordered" to "NIEZAMÓWIONE",
    "rest to at least 20% energy before building." to "Odpocznij, aby mieć co najmniej 20% energii przed budową.",
    "order missing materials" to "Zamów brakujące materiały",
    "you need " to "Potrzebujesz ",
    "earn money first" to "Najpierw zarób pieniądze",
    "recent life events" to "OSTATNIE WYDARZENIA",
    "earn a living" to "ZARABIAJ NA ŻYCIE",
    "your time has value" to "Twój czas ma wartość",
    "work pays the bills. hard shifts cost energy; resting costs a day of living expenses." to "Praca opłaca rachunki. Ciężka zmiana kosztuje energię, a odpoczynek oznacza kolejny dzień wydatków.",
    "energy" to "Energia",
    "available" to "dostępne",
    "ready for work" to "Gotowy do pracy",
    "take it steady" to "Nie przemęczaj się",
    "need rest" to "Potrzebny odpoczynek",
    "living costs: " to "Koszty życia: ",
    " per day" to " dziennie",
    "current savings: " to "Obecne oszczędności: ",
    "construction helper" to "Pomocnik budowlany",
    "carry materials and help a local crew" to "Noś materiały i pomagaj lokalnej ekipie",
    "warehouse shift" to "Zmiana w magazynie",
    "pick and pack orders · steady hours" to "Kompletowanie i pakowanie zamówień · stałe godziny",
    "delivery route" to "Trasa dostawcza",
    "deliver parcels around the district" to "Dostarczaj paczki w okolicy",
    "work one shift" to "Pracuj jedną zmianę",
    "you're too tired for a safe shift. rest first." to "Jesteś zbyt zmęczony na bezpieczną zmianę. Najpierw odpocznij.",
    "take a day off" to "Zrób sobie dzień wolny",
    "rest restores up to 58 energy and improves wellbeing a little. you still pay for food, rent and utilities." to "Odpoczynek przywraca do 58 punktów energii i nieco poprawia samopoczucie. Nadal płacisz za jedzenie, czynsz i media.",
    "rest and recover" to "Odpocznij i odzyskaj siły",
    "local suppliers" to "LOKALNI DOSTAWCY",
    "buy what you need" to "Kup to, czego potrzebujesz",
    "materials are priced by real-world units. ordering advances one day and daily living costs still apply." to "Materiały mają ceny za rzeczywiste jednostki. Zamówienie przesuwa czas o dzień, a koszty życia nadal obowiązują.",
    "starter house completed" to "Dom na start ukończony",
    "your construction account is clear for this chapter. buy seeds and animal feed for the garden and coop." to "Etap budowy domu jest rozliczony. Kup nasiona i paszę do ogrodu oraz kurnika.",
    "a complete order for the next stage" to "Kompletne zamówienie na następny etap",
    "order already complete" to "Zamówienie jest już kompletne",
    "order missing items" to "Zamów brakujące elementy",
    "all materials are in your inventory. build the stage from the world tab." to "Wszystkie materiały są w ekwipunku. Rozpocznij budowę w zakładce Świat.",
    "not enough money while keeping daily costs covered. take a shift first." to "Za mało pieniędzy, aby pokryć także codzienne koszty. Najpierw podejmij zmianę.",
    "garden supplies" to "Artykuły ogrodnicze",
    "vegetable seed packet · 80 zł" to "Paczka nasion warzyw · 80 zł",
    "one packet plants one bed. after four days, harvest 20 portions that can be sold at the market." to "Jedna paczka obsiewa jedną grządkę. Po czterech dniach zbierzesz 20 porcji na sprzedaż.",
    "buy seed packet" to "Kup paczkę nasion",
    "poultry supplies" to "Artykuły dla drobiu",
    "feed bag · 65 zł · a fed flock can lay eggs every three days." to "Worek paszy · 65 zł · karmione kury mogą znosić jajka co trzy dni.",
    "buy feed" to "Kup paszę",
    "manage your farm" to "Zarządzaj gospodarstwem",
    "land & livestock" to "ZIEMIA I ZWIERZĘTA",
    "a small working farm" to "Małe gospodarstwo",
    "grow something, care for animals, and learn what it takes to keep a property running." to "Uprawiaj rośliny, opiekuj się zwierzętami i poznaj koszty utrzymania działki.",
    "vegetable garden" to "Ogród warzywny",
    "ready to harvest · 20 portions" to "Gotowe do zbioru · 20 porcji",
    "one bed · seed, grow, harvest, sell" to "Jedna grządka · zasiej, wyhoduj, zbierz, sprzedaj",
    "buy seeds" to "Kup nasiona",
    "plant bed" to "Obsiej grządkę",
    "harvest 20 portions" to "Zbierz 20 porcji",
    "estimated market value: " to "Szacowana wartość na targu: ",
    "sell harvest · " to "Sprzedaj plony · ",
    "chicken coop" to "Kurnik",
    "a basic timber coop and fenced run · 1,000 zł" to "Prosty drewniany kurnik z wybiegiem · 1 000 zł",
    "build the coop first. each healthy hen costs 220 zł. the small coop holds up to four." to "Najpierw zbuduj kurnik. Zdrowa kura kosztuje 220 zł. W kurniku zmieszczą się maksymalnie cztery.",
    "build chicken coop · 1,000 zł" to "Zbuduj kurnik · 1 000 zł",
    "buy hen · 220 zł" to "Kup kurę · 220 zł",
    "buy feed · 65 zł" to "Kup paszę · 65 zł",
    "eggs in storage: " to "Jajka w magazynie: ",
    "feed the flock; every three days, each hen can lay two eggs." to "Karm kury; co trzy dni każda może znieść dwa jajka.",
    "sell · " to "Sprzedaj · ",
    "a realistic trade-off" to "Realny kompromis",
    "farming costs time, water, feed and money. small harvests add a little income but won't replace a job. build your cash reserve before expanding." to "Gospodarstwo wymaga czasu, wody, paszy i pieniędzy. Małe zbiory dają dodatkowy dochód, ale nie zastąpią pracy. Zbuduj rezerwę przed rozbudową.",
    "site preparation" to "Przygotowanie terenu",
    "clear and level the ground" to "Oczyść i wyrównaj teren",
    "mini excavator hire · 1 day" to "Wynajem minikoparki · 1 dzień",
    "compacted gravel" to "Zagęszczony żwir",
    "foundation" to "Fundamenty",
    "a stable base for the house" to "Stabilna podstawa domu",
    "ready-mix concrete" to "Beton towarowy",
    "steel reinforcement" to "Stalowe zbrojenie",
    "formwork kit" to "Zestaw szalunkowy",
    "brickwork" to "Murowanie",
    "load-bearing walls and lintels" to "Ściany nośne i nadproża",
    "ceramic bricks" to "Cegły ceramiczne",
    "masonry mortar" to "Zaprawa murarska",
    "reinforced lintels" to "Nadproża zbrojone",
    "roof" to "Dach",
    "timber structure, membrane and tiles" to "Konstrukcja drewniana, membrana i dachówki",
    "structural timber" to "Drewno konstrukcyjne",
    "roof tiles" to "Dachówki",
    "roof membrane" to "Membrana dachowa",
    "windows & services" to "Okna i instalacje",
    "close the shell and connect utilities" to "Zamknij bryłę i podłącz instalacje",
    "electrical cable" to "Przewód elektryczny",
    "water and waste pipe" to "Rury wodne i kanalizacyjne",
    "double-glazed window" to "Okno dwuszybowe",
    "insulated entrance door" to "Izolowane drzwi wejściowe",
    "interior finish" to "Wykończenie wnętrza",
    "plaster, floors and paint" to "Tynki, podłogi i farba",
    "interior plaster" to "Tynk wewnętrzny",
    "floor finish" to "Wykończenie podłogi",
    "interior paint" to "Farba wewnętrzna",
    "your home is complete. you no longer pay rent." to "Twój dom jest gotowy. Nie płacisz już czynszu.",
    "your home is complete." to "Twój dom jest gotowy.",
    "you no longer pay rent." to "Nie płacisz już czynszu.",
    "welcome back. your life is waiting." to "Witaj ponownie. Twoje życie czeka.",
    "a new life has begun." to "Rozpoczęło się nowe życie.",
    "you took a proper rest. energy recovered." to "Porządnie odpocząłeś. Energia wróciła.",
    "you planted the garden. the vegetables need four days to grow." to "Obsiałeś ogród. Warzywa potrzebują czterech dni, aby urosnąć.",
    "you harvested 20 portions of vegetables." to "Zebrano 20 porcji warzyw.",
    "you bought a packet of vegetable seeds for 80 zł." to "Kupiono paczkę nasion warzyw za 80 zł.",
    "you built a small, fenced chicken coop for 1,000 zł." to "Zbudowano mały, ogrodzony kurnik za 1 000 zł.",
    "you brought home a healthy hen for 220 zł." to "Kupiono zdrową kurę za 220 zł.",
    "you bought a bag of poultry feed for 65 zł." to "Kupiono worek paszy za 65 zł.",
    "your save file is too large." to "Plik zapisu jest zbyt duży.",
    "that job is not available." to "Ta praca jest niedostępna.",
    "you're too tired for a shift. rest first to recover energy." to "Jesteś zbyt zmęczony na zmianę. Najpierw odpocznij, aby odzyskać energię.",
    "your starter home is complete. there's nothing left to build in this chapter." to "Dom na start jest gotowy. W tym rozdziale nie ma już nic do zbudowania.",
    "you already have all materials for this stage. start building." to "Masz już wszystkie materiały do tego etapu. Rozpocznij budowę.",
    "your starter home is complete." to "Dom na start jest gotowy.",
    "you're too tired to build safely. rest first." to "Jesteś zbyt zmęczony, aby bezpiecznie budować. Najpierw odpocznij.",
    "materials are missing. order the " to "Brakuje materiałów. Zamów zestaw na etap: ",
    "buy seeds from the market first." to "Najpierw kup nasiona na targu.",
    "the garden bed is already growing. harvest before planting again." to "Na grządce już rosną warzywa. Zbierz plony przed ponownym siewem.",
    "the vegetables aren't ready yet. they need four full days to grow." to "Warzywa nie są jeszcze gotowe. Potrzebują pełnych czterech dni wzrostu.",
    "there are no vegetables to sell. harvest the garden first." to "Nie ma warzyw na sprzedaż. Najpierw zbierz plony.",
    "you already have a chicken coop." to "Masz już kurnik.",
    "build the coop before buying animals." to "Zbuduj kurnik przed zakupem zwierząt.",
    "this small coop can safely house up to four chickens." to "Ten mały kurnik pomieści bezpiecznie maksymalnie cztery kury.",
    "a healthy hen costs 220 zł. keep money for daily living costs." to "Zdrowa kura kosztuje 220 zł. Zachowaj pieniądze na codzienne koszty życia.",
    "buy a hen first." to "Najpierw kup kurę.",
    "feed costs 65 zł. keep money for daily living costs." to "Pasza kosztuje 65 zł. Zachowaj pieniądze na codzienne koszty życia.",
    "you don't have eggs to sell yet. keep the chickens fed." to "Nie masz jeszcze jajek na sprzedaż. Karm kury.",
    "enter a name for your avatar." to "Wpisz imię awatara.",
    "money is running low. take a paid shift before making more purchases." to "Kończą się pieniądze. Podejmij płatną zmianę przed kolejnymi zakupami.",
    "you inherited a 420 m² plot and have 18,000 zł saved. build a home without running out of money." to "Odziedziczyłeś działkę o powierzchni 420 m² i masz 18 000 zł oszczędności. Zbuduj dom, nie tracąc wszystkich pieniędzy.",
    "this save version is not supported." to "Ta wersja zapisu nie jest obsługiwana.",
    "the save file is too large." to "Plik zapisu jest zbyt duży.",
    "the save file is incomplete. reset the game to start a new life." to "Plik zapisu jest niekompletny. Zresetuj grę, aby rozpocząć nowe życie.",
    "the save file is invalid." to "Plik zapisu jest nieprawidłowy.",
    "the save format is not recognized." to "Nie rozpoznano formatu zapisu.",
    "that action couldn't be completed." to "Nie udało się wykonać tej czynności.",
    "the save could not be opened." to "Nie udało się otworzyć zapisu.",
    "your progress could not be saved." to "Nie udało się zapisać postępów.",
    "a secure screen lock is required to open your saved world." to "Aby otworzyć zapisany świat, wymagana jest bezpieczna blokada ekranu.",
    "could not start secure unlock. check your phone's screen-lock settings." to "Nie można uruchomić bezpiecznego odblokowania. Sprawdź ustawienia blokady ekranu telefonu.",
    "phone security settings" to "Ustawienia zabezpieczeń telefonu",
    "security hardware is temporarily unavailable. try again." to "Moduł zabezpieczeń jest tymczasowo niedostępny. Spróbuj ponownie.",
    "set up a fingerprint, face unlock or secure screen lock in android settings first." to "Najpierw skonfiguruj odcisk palca, rozpoznawanie twarzy lub bezpieczną blokadę ekranu w ustawieniach Androida.",
    "this device has no supported biometric hardware. set up a secure screen lock instead." to "To urządzenie nie ma obsługiwanego sprzętu biometrycznego. Skonfiguruj bezpieczną blokadę ekranu.",
    "too many attempts. unlock your phone and try again." to "Zbyt wiele prób. Odblokuj telefon i spróbuj ponownie.",
    "unlock ground up" to "Odblokuj Ground Up",
    "unlock cancelled. your save remains protected." to "Anulowano odblokowanie. Zapis nadal jest chroniony.",
    "unlock game" to "Odblokuj grę",
    "unlock with your phone's biometric or secure screen lock. your saved world stays encrypted on this device." to "Odblokuj grę biometrią lub bezpieczną blokadą ekranu. Zapisany świat pozostaje zaszyfrowany na tym urządzeniu.",
    "verify it's you to load your saved world." to "Potwierdź swoją tożsamość, aby wczytać zapisany świat.",
    "your life. your land. your choices." to "Twoje życie. Twoja ziemia. Twoje decyzje.",
    "day" to "dzień",
    "days" to "dni",
    "tonnes" to "tony",
    "kg" to "kg",
    "set" to "zestaw",
    "pieces" to "sztuk",
    "piece" to "sztuka",
    "25 kg bags" to "worki 25 kg",
    "m³" to "m³",
    "metres" to "metrów",
    "rolls" to "rolki",
    "m²" to "m²",
    "litres" to "litrów",
    "units" to "sztuk",
    "unit" to "sztuka",
    "you" to "Ty",
    "your property and construction progress, phase 0 of 6" to "Twoja działka i postęp budowy, etap 0 z 6"
)

private val turkish = mapOf(
    "loading your life…" to "Hayatın yükleniyor…",
    "your save couldn't be opened" to "Kayıt dosyan açılamadı",
    "try again" to "Tekrar dene",
    "start a new life" to "Yeni bir hayata başla",
    "starting a new life replaces the unreadable save." to "Yeni bir hayata başlamak okunamayan kaydın yerini alır.",
    "a life, built by you" to "KENDİ KURDUĞUN BİR HAYAT",
    "avatar and game settings" to "Avatar ve oyun ayarları",
    "your life" to "Hayatın",
    "the avatar represents you in this world. your progress is saved on this device." to "Avatarın bu dünyada seni temsil eder. İlerlemen bu cihaza kaydedilir.",
    "avatar name" to "Avatar adı",
    "your save is encrypted on-device. no account or network connection is used." to "Kaydın cihazda şifrelenir. Hesap veya internet bağlantısı kullanılmaz.",
    "language" to "Dil",
    "start over" to "Baştan başla",
    "save avatar" to "Avatarı kaydet",
    "cancel" to "İptal",
    "start a new life?" to "Yeni bir hayata başlansın mı?",
    "this permanently replaces your current local save with a new plot, new budget and day 1. there is no undo." to "Bu işlem mevcut kaydını yeni bir arsa, yeni bir bütçe ve 1. gün ile kalıcı olarak değiştirir. Geri alınamaz.",
    "reset life" to "Hayatı sıfırla",
    "keep playing" to "Oynamaya devam et",
    "world" to "Dünya",
    "work" to "İş",
    "market" to "Pazar",
    "farm" to "Çiftlik",
    "simulated local economy · prices are game estimates, not live quotes" to "SİMÜLE EDİLEN YEREL EKONOMİ · FİYATLAR OYUN TAHMİNLERİDİR, CANLI TEKLİF DEĞİLDİR",
    "your property · 420 m²" to "ARSAN · 420 m²",
    "build a life from the ground up" to "Hayatını temelden kur",
    "a plot, a budget, and real-world choices. every day costs money." to "Bir arsa, bir bütçe ve gerçek hayat kararları. Her günün bir maliyeti var.",
    "your plot" to "ARSAN",
    "your own home" to "Kendi evin",
    "small starter house" to "Başlangıç evi",
    "saving" to "Kaydediliyor",
    "saved" to "Kaydedildi",
    "wellbeing" to "İYİ OLMA",
    "home" to "EV",
    "daily cost" to "GÜNLÜK GİDER",
    "a home of your own." to "Kendi evin.",
    "you've completed the starter house. rent is gone; your daily living costs are lower. keep working on your land, garden and flock." to "Başlangıç evini tamamladın. Artık kira ödemiyorsun ve günlük giderlerin azaldı. Arazinde, bahçende ve kümesinde çalışmaya devam et.",
    "visit local market" to "Yerel pazara git",
    "next construction phase" to "SONRAKİ İNŞAAT AŞAMASI",
    "materials ready" to "Malzemeler hazır",
    "materials still needed" to "Hâlâ gereken malzemeler",
    "ready" to "HAZIR",
    "not ordered" to "SİPARİŞ VERİLMEDİ",
    "rest to at least 20% energy before building." to "İnşaata başlamadan önce en az %20 enerji için dinlen.",
    "order missing materials" to "Eksik malzemeleri sipariş et",
    "earn money first" to "Önce para kazan",
    "recent life events" to "SON YAŞAM OLAYLARI",
    "earn a living" to "GEÇİMİNİ SAĞLA",
    "your time has value" to "Zamanının bir değeri var",
    "work pays the bills. hard shifts cost energy; resting costs a day of living expenses." to "İş faturaları öder. Ağır vardiyalar enerji tüketir; dinlenirken de günlük masraflar devam eder.",
    "energy" to "Enerji",
    "available" to "mevcut",
    "ready for work" to "Çalışmaya hazır",
    "take it steady" to "Kendini çok zorlama",
    "need rest" to "Dinlenmen gerekiyor",
    "current savings: " to "Mevcut birikim: ",
    "construction helper" to "İnşaat işçisi yardımcısı",
    "carry materials and help a local crew" to "Malzeme taşı ve yerel ekibe yardım et",
    "warehouse shift" to "Depo vardiyası",
    "pick and pack orders · steady hours" to "Siparişleri topla ve paketle · düzenli saatler",
    "delivery route" to "Teslimat rotası",
    "deliver parcels around the district" to "Bölgede paket teslim et",
    "work one shift" to "Bir vardiya çalış",
    "you're too tired for a safe shift. rest first." to "Güvenli bir vardiya için çok yorgunsun. Önce dinlen.",
    "take a day off" to "Bir gün izin yap",
    "rest restores up to 58 energy and improves wellbeing a little. you still pay for food, rent and utilities." to "Dinlenmek 58 enerjiye kadar geri kazandırır ve iyi olma hâlini biraz artırır. Yiyecek, kira ve faturaları yine ödersin.",
    "rest and recover" to "Dinlen ve toparlan",
    "local suppliers" to "YEREL TEDARİKÇİLER",
    "buy what you need" to "İhtiyacın olanı al",
    "materials are priced by real-world units. ordering advances one day and daily living costs still apply." to "Malzemeler gerçek ölçü birimleriyle fiyatlandırılır. Sipariş bir gün geçirir; günlük giderler de devam eder.",
    "starter house completed" to "Başlangıç evi tamamlandı",
    "your construction account is clear for this chapter. buy seeds and animal feed for the garden and coop." to "Bu bölümde ev inşaatı tamamlandı. Bahçe ve kümes için tohum ve yem al.",
    "a complete order for the next stage" to "Sonraki aşama için tam sipariş",
    "order already complete" to "Sipariş zaten tamamlandı",
    "order missing items" to "Eksik ürünleri sipariş et",
    "all materials are in your inventory. build the stage from the world tab." to "Tüm malzemeler envanterinde. Dünya sekmesinden inşaata başla.",
    "not enough money while keeping daily costs covered. take a shift first." to "Günlük giderleri de karşılayacak kadar paran yok. Önce bir vardiya çalış.",
    "garden supplies" to "Bahçe malzemeleri",
    "vegetable seed packet · 80 zł" to "Sebze tohumu paketi · 80 zł",
    "one packet plants one bed. after four days, harvest 20 portions that can be sold at the market." to "Bir paket bir yatağı eker. Dört gün sonra pazarda satabileceğin 20 porsiyon hasat edebilirsin.",
    "buy seed packet" to "Tohum paketi al",
    "poultry supplies" to "Kümes malzemeleri",
    "feed bag · 65 zł · a fed flock can lay eggs every three days." to "Yem çuvalı · 65 zł · beslenen tavuklar üç günde bir yumurtlayabilir.",
    "buy feed" to "Yem al",
    "manage your farm" to "Çiftliğini yönet",
    "land & livestock" to "ARAZİ VE HAYVANCILIK",
    "a small working farm" to "Küçük bir çiftlik",
    "grow something, care for animals, and learn what it takes to keep a property running." to "Bir şeyler yetiştir, hayvanlara bak ve bir mülkü ayakta tutmanın ne gerektirdiğini öğren.",
    "vegetable garden" to "Sebze bahçesi",
    "ready to harvest · 20 portions" to "Hasat hazır · 20 porsiyon",
    "one bed · seed, grow, harvest, sell" to "Bir yatak · ek, büyüt, hasat et, sat",
    "buy seeds" to "Tohum al",
    "plant bed" to "Yatağı ek",
    "harvest 20 portions" to "20 porsiyon hasat et",
    "estimated market value: " to "Tahmini pazar değeri: ",
    "sell harvest · " to "Hasadı sat · ",
    "chicken coop" to "Tavuk kümesi",
    "a basic timber coop and fenced run · 1,000 zł" to "Basit ahşap kümes ve çitli alan · 1.000 zł",
    "build the coop first. each healthy hen costs 220 zł. the small coop holds up to four." to "Önce kümesi yap. Sağlıklı bir tavuk 220 zł. Kümes en fazla dört tavuk alır.",
    "build chicken coop · 1,000 zł" to "Tavuk kümesi yap · 1.000 zł",
    "buy hen · 220 zł" to "Tavuk al · 220 zł",
    "buy feed · 65 zł" to "Yem al · 65 zł",
    "eggs in storage: " to "Depodaki yumurta: ",
    "feed the flock; every three days, each hen can lay two eggs." to "Tavukları besle; her tavuk üç günde bir iki yumurta verebilir.",
    "sell · " to "Sat · ",
    "a realistic trade-off" to "Gerçekçi bir denge",
    "farming costs time, water, feed and money. small harvests add a little income but won't replace a job. build your cash reserve before expanding." to "Çiftlik zaman, su, yem ve para ister. Küçük hasatlar biraz gelir sağlar ama işin yerini tutmaz. Genişlemeden önce birikim yap.",
    "site preparation" to "Arazi hazırlığı",
    "clear and level the ground" to "Alanı temizle ve düzle",
    "mini excavator hire · 1 day" to "Mini ekskavatör kiralama · 1 gün",
    "compacted gravel" to "Sıkıştırılmış çakıl",
    "foundation" to "Temel",
    "a stable base for the house" to "Ev için sağlam bir taban",
    "ready-mix concrete" to "Hazır beton",
    "steel reinforcement" to "Çelik donatı",
    "formwork kit" to "Kalıp seti",
    "brickwork" to "Tuğla duvarlar",
    "load-bearing walls and lintels" to "Taşıyıcı duvarlar ve lentolar",
    "ceramic bricks" to "Seramik tuğla",
    "masonry mortar" to "Duvar harcı",
    "reinforced lintels" to "Donatılı lento",
    "roof" to "Çatı",
    "timber structure, membrane and tiles" to "Ahşap taşıyıcı, membran ve kiremit",
    "structural timber" to "Yapısal kereste",
    "roof tiles" to "Çatı kiremiti",
    "roof membrane" to "Çatı membranı",
    "windows & services" to "Pencereler ve tesisat",
    "close the shell and connect utilities" to "Yapıyı kapat ve altyapı bağlantılarını yap",
    "electrical cable" to "Elektrik kablosu",
    "water and waste pipe" to "Su ve atık su borusu",
    "double-glazed window" to "Çift camlı pencere",
    "insulated entrance door" to "Yalıtımlı giriş kapısı",
    "interior finish" to "İç mekân bitişleri",
    "plaster, floors and paint" to "Sıva, zemin ve boya",
    "interior plaster" to "İç sıva",
    "floor finish" to "Zemin kaplaması",
    "interior paint" to "İç cephe boyası",
    "your home is complete. you no longer pay rent." to "Evin tamamlandı. Artık kira ödemezsin.",
    "your home is complete." to "Evin tamamlandı.",
    "you no longer pay rent." to "Artık kira ödemezsin.",
    "welcome back. your life is waiting." to "Tekrar hoş geldin. Hayatın seni bekliyor.",
    "a new life has begun." to "Yeni bir hayat başladı.",
    "you took a proper rest. energy recovered." to "İyice dinlendin. Enerjin yenilendi.",
    "you planted the garden. the vegetables need four days to grow." to "Bahçeye tohum ektin. Sebzelerin büyümesi dört gün sürer.",
    "you harvested 20 portions of vegetables." to "20 porsiyon sebze hasat ettin.",
    "you bought a packet of vegetable seeds for 80 zł." to "80 zł karşılığında sebze tohumu aldın.",
    "you built a small, fenced chicken coop for 1,000 zł." to "1.000 zł karşılığında küçük ve çitli bir tavuk kümesi yaptın.",
    "you brought home a healthy hen for 220 zł." to "220 zł karşılığında sağlıklı bir tavuk aldın.",
    "you bought a bag of poultry feed for 65 zł." to "65 zł karşılığında bir çuval tavuk yemi aldın.",
    "that job is not available." to "Bu iş mevcut değil.",
    "you're too tired for a shift. rest first to recover energy." to "Vardiya için fazla yorgunsun. Enerji toplamak için önce dinlen.",
    "your starter home is complete. there's nothing left to build in this chapter." to "Başlangıç evin tamamlandı. Bu bölümde yapılacak başka bir şey yok.",
    "you already have all materials for this stage. start building." to "Bu aşama için tüm malzemelere sahipsin. İnşaata başla.",
    "your starter home is complete." to "Başlangıç evin tamamlandı.",
    "you're too tired to build safely. rest first." to "Güvenli biçimde inşa etmek için çok yorgunsun. Önce dinlen.",
    "buy seeds from the market first." to "Önce pazardan tohum al.",
    "the garden bed is already growing. harvest before planting again." to "Bahçedeki ürünler büyüyor. Yeniden ekmeden önce hasat et.",
    "the vegetables aren't ready yet. they need four full days to grow." to "Sebzeler henüz hazır değil. Tam dört gün büyümeleri gerekiyor.",
    "there are no vegetables to sell. harvest the garden first." to "Satılacak sebze yok. Önce bahçeyi hasat et.",
    "you already have a chicken coop." to "Zaten bir tavuk kümesin var.",
    "build the coop before buying animals." to "Hayvan almadan önce kümesi yap.",
    "this small coop can safely house up to four chickens." to "Bu küçük kümes en fazla dört tavuğu güvenle barındırır.",
    "a healthy hen costs 220 zł. keep money for daily living costs." to "Sağlıklı bir tavuk 220 zł. Günlük giderler için para ayır.",
    "buy a hen first." to "Önce bir tavuk al.",
    "feed costs 65 zł. keep money for daily living costs." to "Yem 65 zł. Günlük giderler için para ayır.",
    "you don't have eggs to sell yet. keep the chickens fed." to "Henüz satacak yumurtan yok. Tavukları besle.",
    "enter a name for your avatar." to "Avatarın için bir isim gir.",
    "money is running low. take a paid shift before making more purchases." to "Paran azalıyor. Yeni alışverişlerden önce ücretli bir vardiya çalış.",
    "you inherited a 420 m² plot and have 18,000 zł saved. build a home without running out of money." to "420 m² büyüklüğünde bir arsa miras aldın ve 18.000 zł birikimin var. Paran tükenmeden bir ev inşa et.",
    "this save version is not supported." to "Bu kayıt sürümü desteklenmiyor.",
    "the save file is too large." to "Kayıt dosyası çok büyük.",
    "the save file is incomplete. reset the game to start a new life." to "Kayıt dosyası eksik. Yeni bir hayata başlamak için oyunu sıfırla.",
    "the save file is invalid." to "Kayıt dosyası geçersiz.",
    "the save format is not recognized." to "Kayıt biçimi tanınmıyor.",
    "that action couldn't be completed." to "Bu işlem tamamlanamadı.",
    "the save could not be opened." to "Kayıt açılamadı.",
    "your progress could not be saved." to "İlerlemen kaydedilemedi.",
    "a secure screen lock is required to open your saved world." to "Kayıtlı dünyanı açmak için güvenli bir ekran kilidi gerekiyor.",
    "could not start secure unlock. check your phone's screen-lock settings." to "Güvenli kilit açma başlatılamadı. Telefonunun ekran kilidi ayarlarını kontrol et.",
    "phone security settings" to "Telefon güvenlik ayarları",
    "security hardware is temporarily unavailable. try again." to "Güvenlik donanımı geçici olarak kullanılamıyor. Tekrar dene.",
    "set up a fingerprint, face unlock or secure screen lock in android settings first." to "Önce Android ayarlarından parmak izi, yüz tanıma veya güvenli ekran kilidi kur.",
    "this device has no supported biometric hardware. set up a secure screen lock instead." to "Bu cihazda desteklenen biyometrik donanım yok. Bunun yerine güvenli ekran kilidi kur.",
    "too many attempts. unlock your phone and try again." to "Çok fazla deneme yapıldı. Telefonunun kilidini açıp tekrar dene.",
    "unlock ground up" to "Ground Up kilidini aç",
    "unlock cancelled. your save remains protected." to "Kilit açma iptal edildi. Kaydın korunmaya devam ediyor.",
    "unlock game" to "Oyunun kilidini aç",
    "unlock with your phone's biometric or secure screen lock. your saved world stays encrypted on this device." to "Telefonunun biyometrik doğrulaması veya güvenli ekran kilidiyle aç. Kayıtlı dünyan bu cihazda şifreli kalır.",
    "verify it's you to load your saved world." to "Kayıtlı dünyanı yüklemek için kimliğini doğrula.",
    "your life. your land. your choices." to "Hayatın. Arazin. Kararların.",
    "day" to "gün",
    "days" to "gün",
    "tonnes" to "ton",
    "kg" to "kg",
    "set" to "set",
    "pieces" to "adet",
    "piece" to "adet",
    "25 kg bags" to "25 kg torba",
    "m³" to "m³",
    "metres" to "metre",
    "rolls" to "rulo",
    "m²" to "m²",
    "litres" to "litre",
    "units" to "birim",
    "unit" to "birim",
    "you" to "Sen",
    "your property and construction progress, phase 0 of 6" to "Arazin ve inşaat ilerlemen, 6 aşamadan 0. aşama"
)
