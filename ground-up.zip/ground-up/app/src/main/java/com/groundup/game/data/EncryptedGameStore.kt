package com.groundup.game.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.system.Os
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** App-private AES-256-GCM save with a non-exportable Android Keystore key. */
class EncryptedGameStore(context: Context) {
    private val file = File(context.noBackupFilesDir, "groundup-save.vault")
    private val temporaryFile = File(context.noBackupFilesDir, "groundup-save.vault.tmp")

    @Synchronized fun save(revision: Long, state: GameState) {
        if (revision < persistedRevision) return
        val plain = GameStateCodec.encode(state)
        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val encrypted = cipher.doFinal(plain)
            val envelope = MAGIC + byteArrayOf(cipher.iv.size.toByte()) + cipher.iv + encrypted
            temporaryFile.outputStream().use { it.write(envelope); it.fd.sync() }
            Os.rename(temporaryFile.absolutePath, file.absolutePath)
            persistedRevision = revision
        } catch (e: Exception) {
            temporaryFile.delete()
            throw e
        } finally { plain.fill(0) }
    }

    @Synchronized fun load(): GameState {
        if (!file.exists()) return GameState()
        val envelope = file.readBytes()
        require(envelope.size >= MAGIC.size + 1 + 12 + 16) { "The save file is incomplete. Reset the game to start a new life." }
        require(MAGIC.indices.all { envelope[it] == MAGIC[it] }) { "The save format is not recognized." }
        val ivLength = envelope[MAGIC.size].toInt() and 0xff
        require(ivLength == 12 && envelope.size > MAGIC.size + 1 + ivLength) { "The save file is invalid." }
        val start = MAGIC.size + 1
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, envelope.copyOfRange(start, start + ivLength)))
        val plain = cipher.doFinal(envelope.copyOfRange(start + ivLength, envelope.size))
        return try { GameStateCodec.decode(plain) } finally { plain.fill(0) }
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(false)
                .build())
        }.generateKey()
    }

    companion object {
        private const val KEY_ALIAS = "groundup_save_key_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private val MAGIC = byteArrayOf('G'.code.toByte(), 'U'.code.toByte(), 'P'.code.toByte(), '1'.code.toByte())
        @Volatile private var persistedRevision: Long = -1L
    }
}
