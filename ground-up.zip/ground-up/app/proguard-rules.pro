# Ground Up uses platform crypto APIs and no reflection-based serialization.
# Keep application classes named for readable crash reports when minified.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
